# NBA 第一阶段工具

实际工具目录：E:\NBA-Audit-Toolkit

## 已实现
- tools/run_audit.py：只读清单、LabelMe/COCO 与 YOLO 基础检查、600 张去重候选、来源清单与报告。
- tools/aws_preflight.py：固定 nba/us-east-1，只读检查；身份不符立即停止。
- smoke/run_smoke.py：训练环境与数据门禁；smoke/diagnostic.py：工程诊断训练。
- docs/：数据指南、交接手册和编排手册；prompts/：主 Agent + 六个 Subagent 完整 prompts。
- sources/NBA-CV-/：指定 GitHub 仓库本地审计副本。

## 运行
```powershell
cd E:\NBA-Audit-Toolkit
python -m unittest discover -s tests -v
python tools/run_audit.py --config config.json
# 需要 AWS 只读扫描时：
python tools/aws_preflight.py
```

默认审计不训练。训练运行说明见 smoke/README.md。主流程使用 Python 标准库；工程训练复用了本机已有 torch/ultralytics，未安装或修改共享环境。环境实测版本见 smoke/status.json。

runs/latest.txt 指向最近一次审计。图片原件不复制；CSV 路径在本机 E 盘。输出 SHA256=null 表示未完整校验，不能宣称所有数据已去重。大媒体文件采用元数据盘点以避免反复读取数百 GB。

## 结果边界
本轮 GPU 工程 smoke 已完成；数据质量门禁尚未通过。GLM5.3/flash 是可移交的模型路由要求，未配置可验证的服务，因此没有宣称这些模型已执行。AWS 预检可能受 SSO 网络影响。第一阶段不执行长期云训练、上传或删除。

## 人工镜头标注
human_review.csv 用于来源核实与人工复核队列，不直接生成训练集。camera_class 填 side_wide / close_up / replay / advertisement / transition / other；实际镜头可同时有回放属性，最终标签宜采用 camera_view + broadcast_state 双轴。复核来源后填写 reviewer，并确认独立比赛的 train/val/test 划分。未知、未复核数据不能默认为负样本。
