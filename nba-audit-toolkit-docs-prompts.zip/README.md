# Local smoke test

## Observed result
`status.json` is NOT_RUN, not a training success. The local GPU is an RTX 4060 Laptop GPU (8 GB); CUDA and Torch import successfully. No dependency installation was needed or performed.

The candidate `court_v3` is a **33-keypoint court pose** dataset. The existing `court_v4_train/best.pt` is a **court segmentation** model. They cannot be combined as if they shared an annotation contract. Filename-derived game groups also overlap across train/validation (14 groups) and development/test (15 groups); 612 images have no verified game ID. Original data was not edited, and test data was not used for model selection.

An additional positive-only **engineering diagnostic** subsequently completed 32 training + 16 validation images, one epoch, saved/reloaded checkpoint, and validation in 23.89 seconds (training call 23.06 seconds). See `diagnostic/result.json` and `diagnostic.log`. All training/validation losses were finite. The matching segmentation dataset was located in the court-annotation `_yolo/dataset_v4` folder; its build script randomly splits frames from the same game and uses unverified human-label heuristics. Therefore independent data-quality acceptance remains NOT_RUN. No full-epoch estimate is claimed. Hashes identify the 32/16 candidate files inspected; they do not signify acceptance.

## Commands

Probe the existing environment/data without training:

```powershell
python E:/NBA-Audit-Toolkit/smoke/run_smoke.py
```

Once a **genuinely audited** compatible manifest exists, execute a single bounded train/validation/reload loop in a fresh output folder:

```powershell
python E:/NBA-Audit-Toolkit/smoke/run_smoke.py --manifest E:/path/to/audited-smoke-manifest.json --out E:/NBA-Audit-Toolkit/smoke/accepted-run-001
```

A manifest must contain `gate: PASS`, `video_split_verified: true`, `annotation_verified: true`, `task`, `weights`, `names` (class-ID dictionary), and `samples.train`/`samples.val`. Each sample needs `image`, `label`, `video_id`, image `sha256`, and `label_sha256`. Pose additionally needs `kpt_shape`. Do not set gate fields merely to bypass a check. Hashes and train/val separation are rechecked. A fresh output directory is required to prevent stale checkpoints/results from producing a false PASS.

Bounds: at most 32 train and 16 val images, one epoch, 320-pixel images, batch 2, workers 0, AMP off, 900-second supervised worker deadline. Original images/labels are copied into the run folder so Ultralytics caches cannot modify source directories. Finite losses, a saved/reloaded checkpoint, and executed validation are required for PASS. Full-epoch extrapolation remains null until measured per-step throughput and total dataset size are available. This is an engineering smoke result, not model-quality acceptance.

Installed Ultralytics 8.4.171 differs from the cloud entrypoint requirement `>=8.3.63,<8.4`; any real reproduction run must use a separately pinned environment. The tool does not modify any shared Python installation.


## Repeat the engineering diagnostic safely

```powershell
python E:/NBA-Audit-Toolkit/smoke/diagnostic.py
```

The supervisor creates a unique timestamp/UUID directory under `smoke/diagnostic_runs/`, enforces the 900-second process deadline, and writes `training.log`, `supervisor.json` and, upon success, `result.json`. It does not overwrite the original measured `smoke/diagnostic/` evidence or the top-level `status.json`. To choose a destination, pass `--out E:/NBA-Audit-Toolkit/smoke/my-new-diagnostic`; the path must not already exist. `--worker` is an internal supervisor flag, not a standalone user command. This diagnostic remains engineering-only, because the same-game frame split cannot establish independent evaluation quality.
