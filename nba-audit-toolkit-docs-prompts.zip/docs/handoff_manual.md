# NBA 第一阶段交接手册

交接范围：审计、数据指南、主 Agent + 6 个 Subagent prompts、本地最小训练验证。原始数据保持原位；工具位于 E:/NBA-Audit-Toolkit。云端长训、大批量实验、资源删除属于后续阶段。

## 操作入口

在 PowerShell 中执行：

```powershell
Set-Location 'E:/NBA-Audit-Toolkit'
python tools/run_audit.py --config config.json
python -m unittest discover -s tests -v
```

可选只读 AWS 预检：在上一条审计命令加 `--aws-preflight`。所有 AWS 查询必须明确 nba/us-east-1，先验证账号 766815611718 和 NBAHackathonParticipantRole。登录失败应报告错误，不切换默认 profile。

打开最新 runs/<timestamp>/handoff_manual.md 查看实际盘点和门禁；本文不是本次运行通过的声明。原始数据/模型哈希、GitHub commit、命令、设备、依赖和错误均应关联该 run，避免混用多次报告。

## 接手顺序

1. 阅读 docs/data_guide.md，核对 config.json 来源根目录及排除项。
2. 检查 dataset_manifest.json、repo_sources.json 的缺失来源与同步状态。
3. 检查 annotation_audit.json、split_audit.json，解决错标签、缺 provenance、同视频跨 split。
4. 在 human_review.csv 完成人工复核；模型建议不能代签人工验收。
5. 阅读 smoke/status.json。PASS 必须有真实数据训练、验证、有限 loss、checkpoint 保存并加载；仅 import 或合成数据不算。
6. 如启用预检，读取 cloud_preflight.json，核实已有 court-v5 任务后才规划下一阶段，避免重复启动。
7. 按 prompts/00_main.md 编排，并保存每个子任务证据。GLM 路由未经实际验证时保持 MODEL_UNAVAILABLE。

## 交付物与验收

| 文件（相对 run） | 接收时检查 |
|---|---|
| dataset_manifest.json | 覆盖范围、文件数、总字节、哈希策略、跳过与错误 |
| repo_sources.json | URL、SHA、同步时间、许可证及缺失大文件 |
| annotation_audit.json | 支持/不支持格式、错误与空标签分开 |
| split_audit.json | 文件/视频级泄漏、未知分组；未发现不等于已证明 |
| human_review.csv | 500–700 个唯一真实样本、固定随机种子、human_pending |
| smoke/status.json | PASS/FAIL/NOT_RUN、训练数据、验证、checkpoint 与实际耗时 |
| cloud_preflight.json | 可选，身份校验、逐 API 成败；无查询不得称云端空白 |
| handoff_manual.md | 当前门禁、阻塞、局限与下一步 |

门禁状态 PASS、FAIL、NOT_RUN、UNSYNCED 的证据不能互换。报告生成成功不代表数据或训练通过。实际完整性不足时交接应准确保留阻塞，不伪造合格数值。

## 后续训练建议

先做五类镜头分类，以宏 F1、逐类召回、混淆矩阵、按镜头/比赛划分的失败样例评估；不把检测 mAP 用作分类指标。球场分割用 IoU/Dice 与几何标定误差；目标检测用 mAP50-95；骨骼用关键点误差/PCK或OKS；跟踪用 IDF1/HOTA。所有阈值先用基线及业务目标确定并冻结，再看测试集。

算力预估应来自当前设备、图像尺寸、batch、实际 step/s，包含验证与写盘开销；元数据只能说明实例配置，不能证明 GPU 利用率、磁盘可用空间或网络吞吐。大批量训练需有预算、最大实验数、早停条件、可恢复 checkpoint、日志流和数据校验。未经明确时间/时区与临时资源清单，不能自动执行“9点全部清空”。

## 不可继承的历史结论

旧 README 所列训练活动、GPU、mAP、进入层准确率属于来源的历史陈述。本轮只有机器报告与对应证据才是实测。不会改写其他模型的任务文件、结束其进程、重复运行启动器或从日志提取 API 密钥。


## GitHub 固定版本补充审计（2026-10-08）

本轮同步版本：`1378229118f77524237709ab89957f34c08b1512`；它不同于此前对话记录的 SHA。已读取本地克隆中的 NBA_数据交接手册.md、checks.json、summary_court_v8s_seg.json、report_final.md。64 个 tracked files 未发现 LICENSE 文件，授权状态为待核实；文档可读不等于允许传播所有比赛数据。

- 远程交接手册记录 pose_subcoco 的 17 点人体骨骼、court_v3 的 33 点球场关键点、ball_foot_player_v7 的 ball/foot/player 三类。这是三个不同数据合同，不可混用本地 player/referee/ball/hoop 映射。
- 远程手册记载 B1 v2 的 10,420 条弱标签中 replay 仅 22 条，缺少广告/转场专门类。这是来源报告的历史分布，不是本轮逐标签重算；人工候选需补稀有类别。
- 远程镜头 ID 使用 wide_court/player_closeup/replay/advertisement/broadcast_transition/other_uncertain。本指南 side_wide→wide_court、single_closeup→player_closeup、unknown→other_uncertain 仅为建议映射，导出前冻结映射版本，不能静默改原标签。普通机位硬切不算导播包装转场。
- summary_court_v8s_seg.json 声明 yolov8s-seg、100 个请求 epoch、640 尺寸、batch 32、33.08 分钟；val_best 的框 mAP50-95≈0.89377、分割 mAP50-95≈0.86518。同时明确 test_error="dataset has no test split"。这些是远程既有运行的声明，不能当独立测试表现，也不能作为本地吞吐估计。
- checks.json 的 verdict=pass 检查的是 DOCX 包和文本包含 basketball_court/mAP@50-95/best.pt，不是数据、模型精度或训练验收。
- report_final.md 是进入层规则/语料评估，声明 200 条 synthetic 语料、50 条 gold、分类 100%、综合槽位 F1=0.9917；真实 LLM 延迟待测。不能当真实用户泛化、GLM 性能或 CV 分类表现。
- 远程手册开头说两项 pose 作业于 10/7 停止且无最终指标，但其内嵌 prompt 仍写“正在运行”，存在内部旧文本冲突；以本次 AWS 作业状态作为当前证据。
- 远程手册声称交接目录 124,982 文件、约 60.17 GB；克隆文档及 best.pt 不证明这些完整原始视频/标签均随 Git 获取。本轮 manifest 的实际路径覆盖才是本地可用性依据。

本地 knowledge_base 的球员卡已登记到 docs/player_sources.json。卡片标题 2025-26，统计列 2024-25，抓取日期缺失；队伍归属和时间对齐必须再次核验。三分%列出现 0.43 等值，保留原值并标单位歧义，不自动放大/缩小。来源声明“内部研究”不是对外再分发许可证。球员身高等文档记录为 source_claim，未做官方实时核验；体重/臂展/弹跳与分区概率目前保持 null。
