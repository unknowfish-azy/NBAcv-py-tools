# NBA CV 骨骼与人物识别工具 v0.2

这是源码工具包。生成结果、视频、权重、`.pyc` 不属于源码发布物；不要提交到版本库。

## 骨骼 CLI

```powershell
python run_cv_tools.py skeleton <input.json|目录> <output.json> --format auto --max-displacement 50
```

支持 LabelMe points 和显式 pose17/tracks JSON。输出带 COCO17 joint_names、track_id、逐点 issues、`PASS/REVIEW/NOT_RUN` 时序门禁。`--normalized-threshold 0.25` 可按人物 bbox 高度归一化位移阈值。

## 身份 CLI

```powershell
python run_cv_tools.py identity tracks.jsonl roster.json identity.json
```

输入轨迹必须带秒级 `timestamp`、`track_id`、`team_score`、`jersey_score`。JSONL 每行一条轨迹观察；输入对象中的已有身份字段会保存在 `input`，解析结果单独放在 `resolution`，不会覆盖上游证据。

## 视频管线

见 `skills/nba-player-evidence/SKILL.md`。使用绝对路径只是命令示例；在其他机器上替换为本地视频、模型和输出路径。

未知身份、缺失关键点、遮挡和未确认下场都保持未知状态。分数是 `evidence_score`，不是校准概率。


视频示例（在工具目录执行）：
```powershell
python video_identity_pipeline.py --video game.mp4 --model players.pt --ffmpeg /path/to/ffmpeg --out new-run --seconds 10 --fps 5 --ocr
```
默认每秒采样5帧；不是原视频全帧分析。轨迹是像素位置，不是真实球场速度。球鞋ROI与外观颜色仍是启发式候选，号码OCR实测短片未获得可靠数字；未验证身份准确率或ReID泛化率。
LabelMe自动人工确认仅支持本项目约定的每个shape.flags.human_verified=true及flags.reviewer；这不是LabelMe统一标准。顶层checked不传播到每个人。单点shape的命名分组导入尚不支持；points数组必须已经按COCO17排列。二维坐标不擅自推断可见性，第三列0为未标注，1为已标注遮挡，2为可见。
未知track_id的历史pose17文件只做空间/格式检查，时序为NOT_RUN；不能用person_index假装跨帧身份。旧schema nba.pose17.v1升级为v2；消费端请使用rows及temporal字段。

运行全部测试：`python -m unittest discover -s tests -v`。
安装纯JSON工具：`python -m pip install .`；视觉可选依赖：`python -m pip install ".[video,ocr]"`。模型权重及ffmpeg需另行提供。依赖范围非锁定环境，实测平台为当前Windows本机。
