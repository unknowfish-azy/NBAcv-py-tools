"""Portable JSON/JSONL CLI. Exit 2=input/IO error; exit 1=invalid annotation."""
import argparse,json,sys
from pathlib import Path
from skeleton_labeler import normalize_file,detect_temporal_jumps
from identity_evidence import IdentityResolver
from player_identity_cv import build_identity_report

def read_records(path):
 p=Path(path);text=p.read_text(encoding='utf-8-sig')
 return [json.loads(line) for line in text.splitlines() if line.strip()] if p.suffix.lower()=='.jsonl' else json.loads(text)
def save(out,result):
 out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('x',encoding='utf8') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False)
def skeleton_cmd(inp,out,expected=17,input_format='auto',max_displacement=50,normalized_threshold=None):
 src=Path(inp)
 if not src.exists():raise ValueError('Input does not exist')
 if Path(out).exists():raise ValueError('Output exists; use a new path')
 files=[src] if src.is_file() else sorted(p for p in src.glob('*.json') if p.resolve()!=Path(out).resolve())
 if not files:raise ValueError('No input JSON files')
 results=[]
 for p in files:
  try:
   r=normalize_file(p,expected,input_format);r['source_file']=str(p)
   rows=r.get('rows')
   if rows is None:rows=[dict(x,frame=0) for x in r.get('people',[])]
   r['temporal']=detect_temporal_jumps(rows,max_displacement,normalized_threshold)
   results.append(r)
  except (ValueError,TypeError,OSError) as e:results.append({'source_file':str(p),'status':'invalid','error':str(e)})
 save(out,{'schema':'nba.pose17.v2','files':results})
 return {'files':len(results),'invalid':sum(x['status']=='invalid' for x in results)}
def identity_cmd(tracks,roster,out):
 data=read_records(tracks);players=read_records(roster)
 rows=data if isinstance(data,list) else data.get('tracks',data.get('rows'))
 players=players if isinstance(players,list) else players.get('players')
 if not isinstance(rows,list) or not isinstance(players,list) or any(not isinstance(x,dict) for x in rows+players):raise ValueError('tracks and players must be arrays of objects')
 resolver=IdentityResolver();resolved=[]
 for r in rows:
  candidate=resolver.update(r,players)
  resolved.append({'input':r,'resolution':candidate})
 flat=[x['resolution'] for x in resolved]
 result={'schema':'nba.identity.v2','rows':resolved,'report':build_identity_report(flat),'unknown_queue':[r for r in resolved if r['resolution']['identity']=='unknown']}
 save(out,result);return result['report']
def main():
 ap=argparse.ArgumentParser(description=__doc__);sub=ap.add_subparsers(dest='cmd',required=True)
 s=sub.add_parser('skeleton');s.add_argument('input');s.add_argument('output');s.add_argument('--expected-points',type=int,default=17);s.add_argument('--format',choices=['auto','labelme','pose17','tracks'],default='auto');s.add_argument('--max-displacement',type=float,default=50);s.add_argument('--normalized-threshold',type=float)
 i=sub.add_parser('identity');i.add_argument('tracks');i.add_argument('roster');i.add_argument('output');a=ap.parse_args()
 try:
  result=skeleton_cmd(a.input,a.output,a.expected_points,a.format,a.max_displacement,a.normalized_threshold) if a.cmd=='skeleton' else identity_cmd(a.tracks,a.roster,a.output)
  print(json.dumps(result,ensure_ascii=False));return 1 if result.get('invalid',0) else 0
 except (ValueError,TypeError,OSError,KeyError) as e:
  print(json.dumps({'status':'ERROR','error':str(e)},ensure_ascii=False),file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
