"""COCO17 normalization with per-joint validation and explicit temporal gates."""
import json, math, re
from pathlib import Path
COCO17=['nose','left_eye','right_eye','left_ear','right_ear','left_shoulder','right_shoulder','left_elbow','right_elbow','left_wrist','right_wrist','left_hip','right_hip','left_knee','right_knee','left_ankle','right_ankle']
def frame_number(value):
 if isinstance(value,(int,float)):return float(value)
 parts=re.findall(r'\d+',str(value));return int(parts[-1]) if parts else 0

def validate_pose(keypoints,width=None,height=None):
 out=[];issues=[]
 if not isinstance(keypoints,list):return {'invalid':1,'keypoints':[],'issues':['points_not_array']}
 for i,p in enumerate(keypoints):
  bad=not isinstance(p,(list,tuple)) or len(p) not in (2,3)
  if not bad:
   x,y=p[:2];v=p[2] if len(p)==3 else 0
   bad=not all(isinstance(n,(int,float)) and not isinstance(n,bool) and math.isfinite(n) for n in (x,y)) or v not in (0,1,2)
   if not bad:bad=x<0 or y<0 or (width is not None and x>width) or (height is not None and y>height)
  if bad:out.append([None,None,0]);issues.append({'joint_index':i,'reason':'invalid_coordinate_or_visibility'})
  else:out.append([float(x),float(y),int(v)])
 return {'invalid':len(issues),'keypoints':out,'issues':issues}

def parse_labelme(data,expected_points=17):
 if expected_points!=17:raise ValueError('Only COCO17 human pose supported; court keypoints need separate schema')
 if not isinstance(data,dict) or not isinstance(data.get('shapes'),list):raise ValueError('Expected LabelMe shapes array')
 people=[];ignored=0
 for s in data['shapes']:
  if not isinstance(s,dict) or s.get('shape_type')!='points':ignored+=1;continue
  q=validate_pose(s.get('points'),data.get('imageWidth'),data.get('imageHeight'))
  flags=s.get('flags') or {};review=flags.get('human_verified') is True and isinstance(flags.get('reviewer'),str) and bool(flags['reviewer'].strip())
  status='invalid' if q['invalid'] or len(q['keypoints'])!=17 else 'human_verified' if review else 'human_pending'
  people.append({'label':s.get('label'),'track_id':s.get('group_id'),'joint_names':COCO17,'keypoints':q['keypoints'],'status':status,'issues':q['issues'],'review_source':flags if review else None})
 return {'schema':'nba.pose17.v2','status':'invalid' if any(p['status']=='invalid' for p in people) else 'human_pending','people':people,'ignored_shapes':ignored,'image_width':data.get('imageWidth'),'image_height':data.get('imageHeight')}

def detect_temporal_jumps(rows,max_displacement=50,normalized_threshold=None):
 if max_displacement<=0 or (normalized_threshold is not None and normalized_threshold<=0):raise ValueError('Threshold must be positive')
 prior={};out=[]
 for row in sorted(rows,key=lambda r:frame_number(r.get('frame',r.get('timestamp',0)))):
  item=dict(row);reasons=[];kp=row.get('keypoints',[]);names=row.get('joint_names',COCO17)
  if len(kp)!=17 or names!=COCO17:reasons.append('missing_or_incompatible_joint_layout')
  tid=row.get('track_id');key=(row.get('video_id'),row.get('shot_id',0),tid)
  valid=validate_pose(kp);cur={COCO17[i]:p for i,p in enumerate(valid['keypoints'][:17]) if p[0] is not None and p[2]>0}
  if valid['invalid']:reasons.append('invalid_points')
  old=prior.get(key) if tid is not None else None;threshold=max_displacement
  if normalized_threshold is not None:
   box=row.get('bbox');scale=(box[3]-box[1]) if isinstance(box,list) and len(box)==4 else row.get('image_height')
   if not isinstance(scale,(int,float)) or scale<=0:reasons.append('missing_normalization_scale');old=None
   else:threshold=normalized_threshold*scale
  if old is not None:
   for name in old.keys() & cur.keys():
    distance=math.dist(old[name][:2],cur[name][:2])
    if distance>threshold:reasons.append({'joint':name,'displacement_px':distance,'threshold_px':threshold})
  item['temporal_status']='NOT_RUN' if tid is None or old is None else 'REVIEW' if reasons else 'PASS'
  item['review_reasons']=reasons+(['missing_track_id'] if tid is None else [])
  item['status']='review' if reasons else row.get('status','human_pending')
  out.append(item)
  if tid is not None:prior[key]=cur
 return out

def normalize_file(path,expected_points=17,input_format='auto'):
 if expected_points!=17:raise ValueError('Expected human COCO17, not court layout')
 data=json.loads(Path(path).read_text(encoding='utf-8-sig'))
 if input_format=='labelme' or (input_format=='auto' and isinstance(data,dict) and 'shapes' in data):return parse_labelme(data)
 if input_format not in ('auto','pose17','tracks'):raise ValueError('Unsupported format')
 if isinstance(data,list):rows=data
 elif isinstance(data,dict) and isinstance(data.get('rows'),list):rows=data['rows']
 elif isinstance(data,dict) and data and all(isinstance(v,list) for v in data.values()):
  rows=[dict(p,frame=frame) for frame,persons in data.items() for p in persons if isinstance(p,dict)]
 else:raise ValueError('Unsupported pose structure; specify labelme, pose17 or tracks')
 normalized=[]
 for row in rows:
  if not isinstance(row,dict):normalized.append({'frame':0,'keypoints':[],'status':'invalid'});continue
  raw=row.get('keypoints',row.get('kpts',[]));raw=raw if isinstance(raw,list) else []
  if len(raw)==51 and all(isinstance(x,(int,float)) for x in raw):raw=[raw[i:i+3] for i in range(0,51,3)]
  q=validate_pose(raw,row.get('image_width'),row.get('image_height'));n=dict(row,keypoints=q['keypoints'],joint_names=COCO17,status='invalid' if q['invalid'] or len(raw)!=17 else 'human_pending',issues=q['issues'])
  if not row.get('image_width') or not row.get('image_height'):
   n['bounds_check']='NOT_RUN'; n['status']='NOT_RUN' if not q['invalid'] and len(raw)==17 else 'invalid'
  n['visibility_source']='annotation_v' if 'keypoints' in row else 'unknown_model_confidence_not_visibility'
  n['bounds_check']='CHECKED' if row.get('image_width') and row.get('image_height') else 'NOT_RUN'
  normalized.append(n)
 return {'schema':'nba.pose17.v2','status':'invalid' if any(r['status']=='invalid' for r in normalized) else 'human_pending','rows':sorted(normalized,key=lambda r:frame_number(r.get('frame',0)))}
