import unittest,sys,tempfile,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from skeleton_labeler import *
from identity_evidence import IdentityResolver
class ReviewRegression(unittest.TestCase):
 def test_missing_tail(self):
  r=detect_temporal_jumps([{'frame':1,'track_id':1,'keypoints':[[0,0,2]]*17},{'frame':2,'track_id':1,'keypoints':[[0,0,2]]*16}])
  self.assertEqual(r[1]['status'],'review')
 def test_one_joint_jump(self):
  r=detect_temporal_jumps([{'frame':1,'track_id':1,'keypoints':[[0,0,2]]*17},{'frame':2,'track_id':1,'keypoints':[[0,0,2]]*16+[[100,0,2]]}],20)
  self.assertEqual(r[1]['status'],'review')
 def test_no_track_not_pass(self):
  self.assertEqual(detect_temporal_jumps([{'frame':1,'keypoints':[[0,0,2]]*17}])[0]['temporal_status'],'NOT_RUN')
 def test_polygon_not_pose(self):
  r=parse_labelme({'imageWidth':100,'imageHeight':100,'shapes':[{'shape_type':'polygon','points':[[1,2]]*17}]})
  self.assertEqual(r['people'],[])
 def test_bad_point_preserved(self):
  r=parse_labelme({'imageWidth':100,'imageHeight':100,'shapes':[{'shape_type':'points','points':[[1,2]]*17+[None]}]})
  self.assertEqual(r['people'][0]['status'],'invalid')
 def test_number_types_and_threshold(self):
  roster=[{'player_id':'p','team':'HOU','jersey_number':'7'}]
  def run(threshold):
   m=IdentityResolver(min_jersey=threshold)
   for t in [0,1,2]:r=m.update({'timestamp':t,'track_id':1,'team':' hou ','team_score':.9,'jersey_number':7.0,'jersey_score':.85},roster)
   return r
  self.assertEqual(run(.8)['identity'],'p');self.assertEqual(run(.9)['identity'],'unknown')
 def test_cli_connected(self):
  from run_cv_tools import skeleton_cmd
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'in.json';out=Path(td)/'out.json'
   p.write_text(json.dumps([{'frame':1,'track_id':1,'keypoints':[[0,0,2]]*17},{'frame':2,'track_id':1,'keypoints':[[100,0,2]]*17}]))
   skeleton_cmd(p,out,17)
   r=json.loads(out.read_text())
   self.assertEqual(r['files'][0]['temporal'][1]['status'],'review')
