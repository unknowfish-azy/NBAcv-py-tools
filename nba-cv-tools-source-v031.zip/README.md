# NBA CV 骨骼与人物识别工具 v0.3.1

这是源码工具包。生成结果、视频、权重、`.pyc` 不属于源码发布物；不要提交到版本库。

## 骨骼 CLI

```powershell
python run_cv_tools.py skeleton <input.json|目录> <output.json> --format auto --max-displacement 50
```

支持 LabelMe points 和显式 pose17/tracks JSON。目录模式要获得跨文件时序结果，必须提供稳定的 `--track-map` 或明确使用 `--group-id-is-track`；未提供稳定 ID 时输出 `NOT_RUN`。`--fps` 将文件名末尾数字转换为时间戳，`--max-speed` 和 `--max-gap` 执行速度/断档门禁。

## 身份 CLI

```powershell
python run_cv_tools.py identity tracks.jsonl roster.json identity.json
```

输入轨迹必须带秒级 `timestamp`、`track_id`、`team_score`、`jersey_score`。输出行同时提供平铺解析字段和 `resolution`，上游字段保存在 `input`。人工证据支持 `shot_id`、过期和带 `evidence_id` 的撤销；AI/视觉模型复核必须显式标记为 model。

## 视频管线

见 `skills/nba-player-evidence/SKILL.md`。管线支持 `--video` 和已有帧目录 `--frames-dir`；视频模式从 PATH 探测 ffmpeg/ffprobe，也可用 `--ffmpeg`、`--ffprobe` 覆盖。

未知身份、缺失关键点、遮挡和未确认下场都保持未知状态。分数是 `evidence_score`，不是校准概率。


视频示例（在工具目录执行）：
```powershell
python video_identity_pipeline.py --video game.mp4 --model players.pt --ffmpeg /path/to/ffmpeg --out new-run --seconds 10 --fps 5 --ocr
```
默认每秒采样5帧；不是原视频全帧分析。关键点会执行速度/断档门禁，鞋色字段明确标为 bbox proxy，不作为强身份证据；颜色映射只产生球队候选，不直接确认球队。复核队列只包含未知、低分、冲突、未跟踪和时序异常，manifest 提供复核率和原因计数。
LabelMe自动人工确认仅支持本项目约定的每个shape.flags.human_verified=true及flags.reviewer；这不是LabelMe统一标准。顶层checked不传播到每个人。跨文件时序需要标签映射或明确 group_id 语义；单点 LabelMe 不提供模型置信度，默认不比较未标记点，使用 `--compare-unmarked-points` 才会显式采用二维坐标假设。
未知track_id的历史pose17文件只做空间/格式检查，时序为NOT_RUN；不能用person_index假装跨帧身份。旧schema nba.pose17.v1升级为v2；消费端请使用rows及temporal字段。

运行全部测试：`python -m unittest discover -s tests -v`（当前 70 项）。
安装纯JSON工具：`python -m pip install .`；视觉可选依赖：`python -m pip install ".[video,ocr]"`。模型权重及ffmpeg需另行提供。依赖范围非锁定环境，实测平台为当前Windows本机。
