import unittest,tempfile,json,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from skeleton_labeler import normalize_file,parse_labelme,detect_temporal_jumps
CLI=Path(__file__).resolve().parents[1]/'run_cv_tools.py'
class EndToEnd(unittest.TestCase):
 def test_missing_input_exit(self):
  r=subprocess.run([sys.executable,str(CLI),'skeleton','__absent__.json','__never_created__.json'],capture_output=True,text=True)
  self.assertEqual(r.returncode,2);self.assertEqual(json.loads(r.stderr)['status'],'ERROR')
 def test_jsonl_preserves_input(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td);obs=[{'timestamp':t,'track_id':1,'team':'HOU','team_score':.95,'jersey_score':.95,'jersey_number':7.0,'identity':'upstream'} for t in [0,1,2]]
   (p/'a.jsonl').write_text('\n'.join(map(json.dumps,obs)));(p/'r.json').write_text(json.dumps([{'team':'HOU','jersey_number':7,'player_id':'p7'}]))
   cmd=[sys.executable,str(CLI),'identity',str(p/'a.jsonl'),str(p/'r.json'),str(p/'out.json')]
   r=subprocess.run(cmd,capture_output=True,text=True);self.assertEqual(r.returncode,0,r.stderr)
   rows=json.loads((p/'out.json').read_text())['rows'];self.assertEqual(rows[-1]['input']['identity'],'upstream');self.assertEqual(rows[-1]['resolution']['identity'],'p7');self.assertEqual(rows[-1]['identity'],'p7');self.assertEqual(rows[-1]['identity_status'],'provisional')
   self.assertEqual(subprocess.run(cmd,capture_output=True).returncode,2)
 def test_missing_roster_id(self):
  from identity_evidence import IdentityResolver
  m=IdentityResolver()
  for t in [0,1,2]:r=m.update({'timestamp':t,'track_id':1,'team':'HOU','team_score':.9,'jersey_score':.9,'jersey_number':7},[{'team':'HOU','jersey_number':7}])
  self.assertEqual(r['identity'],'unknown');self.assertEqual(r['evidence_score'],0)
 def test_occluded_not_compared(self):
  rows=[{'frame':t,'track_id':1,'keypoints':[[t*100,0,0]]*17} for t in [0,1]]
  self.assertNotEqual(detect_temporal_jumps(rows,20)[1]['status'],'review')
 def test_numeric_sort_and_point_error_locality(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'p.json';p.write_text(json.dumps({'t10.jpg':[{'kpts':[[0,0]]*17,'scores':[.9]*17}],'t2.jpg':[{'kpts':[None]+[[0,0]]*16}]}))
   rows=normalize_file(p)['rows'];self.assertEqual(rows[0]['frame'],'t2.jpg');self.assertEqual(rows[0]['status'],'invalid');self.assertNotEqual(rows[1]['status'],'invalid')
 def test_shape_review_granularity(self):
  shape={'shape_type':'points','points':[[1,1]]*17}
  d={'imageWidth':10,'imageHeight':10,'checked':True,'reviewer':'top','shapes':[dict(shape,flags={'human_verified':True,'reviewer':'one'}),shape]}
  people=parse_labelme(d)['people'];self.assertEqual(people[0]['status'],'human_verified');self.assertEqual(people[1]['status'],'human_pending')
