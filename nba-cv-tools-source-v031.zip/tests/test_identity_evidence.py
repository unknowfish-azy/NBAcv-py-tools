import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from identity_evidence import IdentityResolver, histogram_similarity

ROSTER = [dict(player_id='a', name='A', team='home', jersey_number='23'),
          dict(player_id='b', name='B', team='away', jersey_number='23')]

def obs(t=0, **kw):
    row = dict(track_id=1, shot_id=0, timestamp=t, team='home', team_score=.95,
               jersey_number='23', jersey_score=.95, evidence_source='ocr')
    row.update(kw)
    return row

class IdentityTests(unittest.TestCase):
    def test_one_frame_and_duplicates_do_not_resolve(self):
        r = IdentityResolver()
        for _ in range(5): result = r.update(obs(), ROSTER)
        self.assertEqual(result['identity'], 'unknown')
        self.assertEqual(result['independent_observations'], 1)

    def test_repeated_evidence_resolves_but_is_not_probability(self):
        r = IdentityResolver()
        for t in [0, .5, 1]: result = r.update(obs(t), ROSTER)
        self.assertEqual(result['identity'], 'a')
        self.assertEqual(result['identity_status'], 'provisional')
        self.assertLess(result['evidence_score'], 1)
        self.assertFalse(result['score_calibrated'])

    def test_missing_team_or_low_confidence_cannot_resolve(self):
        for extra in [dict(team=None), dict(team_score=.2), dict(jersey_score=.1)]:
            r = IdentityResolver()
            for t in [0, 1, 2]: result = r.update(obs(t, **extra), ROSTER)
            self.assertEqual(result['identity'], 'unknown')

    def test_conflicting_number_requires_review(self):
        r = IdentityResolver()
        roster = ROSTER + [dict(player_id='c', team='home', jersey_number='24')]
        for t in [0, 1, 2]: r.update(obs(t), roster)
        result = r.update(obs(3, jersey_number='24'), roster)
        self.assertEqual(result['identity'], 'unknown')
        self.assertIn('conflicting_identity_evidence', result['review_reasons'])

    def test_shot_reset_does_not_reuse_identity(self):
        r = IdentityResolver()
        for t in [0, 1, 2]: r.update(obs(t), ROSTER)
        result = r.update(obs(3, shot_id=1, team=None, jersey_number=None), ROSTER)
        self.assertEqual(result['identity'], 'unknown')

    def test_gallery_is_candidate_not_verified(self):
        r = IdentityResolver(gallery=[dict(player_id='a', features={'jersey_histogram':[1,0]})])
        for t in [0, 1, 2]:
            result = r.update(obs(t, team=None, jersey_number=None,
                                 features={'jersey_histogram':[1,0]}), ROSTER)
        self.assertEqual(result['identity'], 'unknown')
        self.assertEqual(result['candidates'][0]['player_id'], 'a')
        self.assertEqual(result['candidates'][0]['basis'], 'appearance_only')

    def test_absence_never_implies_substitution(self):
        r = IdentityResolver()
        for t in [0, 1, 2]: r.update(obs(t), ROSTER)
        self.assertEqual(r.presence(3, [], 0)[0]['screen_state'], 'off_screen')
        self.assertEqual(r.presence(3, [], 0)[0]['court_state'], 'unknown')
        self.assertEqual(r.presence(3, [1], 0)[0]['screen_state'], 'on_screen')
        self.assertEqual(r.presence(4, [], 1)[0]['screen_state'], 'unknown')

    def test_confirmed_substitution_requires_provenance(self):
        r = IdentityResolver()
        for t in [0, 1, 2]: r.update(obs(t), ROSTER)
        invalid = [dict(player_id='a', timestamp=2, status='out', confirmed=True)]
        self.assertEqual(r.presence(3, [], 0, substitution_events=invalid)[0]['court_state'], 'unknown')
        valid = [dict(player_id='a', timestamp=2, status='out', confirmed=True, source='official_play_by_play')]
        self.assertEqual(r.presence(3, [], 0, substitution_events=valid)[0]['court_state'], 'confirmed_substituted_out')

    def test_invalid_timestamp_and_histogram(self):
        with self.assertRaises(ValueError): IdentityResolver().update(obs(float('nan')), ROSTER)
        self.assertEqual(histogram_similarity([0,0], [0,0]), 0)
        self.assertEqual(histogram_similarity([1], [1,2]), 0)

    def test_human_review_evidence_resolves_without_ocr(self):
        r = IdentityResolver(min_repeats=2)
        evidence = [{'type':'human_review','reviewer':'coach','player_id':'a','timestamp':0,'confirmed':True}]
        result = r.update(obs(0, team=None, jersey_number=None, identity_evidence=evidence), ROSTER)
        self.assertEqual(result['identity'], 'a')
        self.assertEqual(result['identity_status'], 'human_confirmed')

    def test_appearance_similarity_contributes_but_threshold_applies(self):
        gallery=[dict(player_id='a', features={'appearance_histogram':[1,0]})]
        r=IdentityResolver(gallery=gallery, min_confidence=.8)
        for t in [0,1,2]:
            result=r.update(obs(t, team_score=.85, jersey_score=.85,
                                features={'appearance_histogram':[1,0]}), ROSTER)
        self.assertEqual(result['identity'], 'a')
        self.assertAlmostEqual(result['evidence_score'], .895)
        strict=IdentityResolver(gallery=gallery,min_confidence=.95)
        for t in [0,1,2]:
            result=strict.update(obs(t,team_score=.85,jersey_score=.85,features={'appearance_histogram':[1,0]}),ROSTER)
        self.assertEqual(result['identity'],'unknown')

    def test_human_review_persists_without_fabricated_ocr(self):
        r=IdentityResolver()
        evidence=[dict(type='human_review',reviewer='coach',player_id='a',timestamp=0,confirmed=True)]
        r.update(obs(0,team=None,jersey_number=None,identity_evidence=evidence),ROSTER)
        result=r.update(obs(1,team=None,jersey_number=None),ROSTER)
        self.assertEqual(result['identity'],'a')

    def test_human_review_expires(self):
        r=IdentityResolver(max_human_duration=10)
        evidence=[dict(type='human_review',reviewer='coach',player_id='a',timestamp=0,confirmed=True)]
        r.update(obs(0,team=None,jersey_number=None,identity_evidence=evidence),ROSTER)
        result=r.update(obs(11,team=None,jersey_number=None),ROSTER)
        self.assertEqual(result['identity'],'unknown')

    def test_model_reviewer_name_requires_explicit_human_kind(self):
        r=IdentityResolver()
        result=r.update(obs(0,team=None,jersey_number=None,identity_evidence=[dict(type='human_review',reviewer='zcode_visual_review',player_id='a',timestamp=0,confirmed=True)]),ROSTER)
        self.assertEqual(result['identity'],'unknown')

    def test_human_review_can_be_limited_to_shot(self):
        r=IdentityResolver()
        evidence=[dict(type='human_review',reviewer='coach',player_id='a',timestamp=0,confirmed=True,shot_id=0)]
        r.update(obs(0,shot_id=0,team=None,jersey_number=None,identity_evidence=evidence),ROSTER)
        result=r.update(obs(1,shot_id=1,team=None,jersey_number=None),ROSTER)
        self.assertEqual(result['identity'],'unknown')

    def test_human_conflicts_block_resolution(self):
        r=IdentityResolver()
        for t,pid in [(0,'a'),(1,'b')]:
            result=r.update(obs(t,identity_evidence=[dict(type='human_review',reviewer='coach',player_id=pid,timestamp=t,confirmed=True)]),ROSTER)
        self.assertEqual(result['identity'],'unknown')
        self.assertIn('conflicting_human_review_evidence',result['review_reasons'])

    def test_invalid_human_review_cannot_resolve(self):
        for changes in [dict(reviewer=''),dict(timestamp=True),dict(timestamp=9),dict(player_id='missing'),dict(confirmed=False)]:
            evidence=dict(type='human_review',reviewer='coach',player_id='a',timestamp=0,confirmed=True)
            evidence.update(changes)
            result=IdentityResolver().update(obs(0,team=None,identity_evidence=[evidence]),ROSTER)
            self.assertEqual(result['identity'],'unknown')

if __name__ == '__main__': unittest.main()

class AdditionalIdentityTests(unittest.TestCase):
    def test_invalid_resolution_threshold_is_rejected(self):
        for threshold in [float('nan'),float('inf'),-.1,1.1]:
            with self.assertRaises(ValueError):IdentityResolver(min_confidence=threshold)

    def test_adjacent_video_frames_not_independent(self):
        r = IdentityResolver()
        for t in [0, .03, .06, .09]: result = r.update(obs(t), ROSTER)
        self.assertEqual(result['independent_observations'], 1)
        self.assertEqual(result['identity'], 'unknown')

    def test_number_zero_supported(self):
        r = IdentityResolver()
        roster = [dict(player_id='zero', team='home', jersey_number=0)]
        for t in [0, 1, 2]: result = r.update(obs(t, jersey_number=0), roster)
        self.assertEqual(result['identity'], 'zero')

    def test_duplicate_roster_mapping_is_ambiguous(self):
        r = IdentityResolver()
        roster = ROSTER + [dict(player_id='duplicate', team='home', jersey_number=23)]
        for t in [0, 1, 2]: result = r.update(obs(t), roster)
        self.assertEqual(result['identity'], 'unknown')
        self.assertIn('ambiguous_roster_match', result['review_reasons'])

    def test_new_substitution_in_supersedes_out(self):
        r = IdentityResolver()
        for t in [0, 1, 2]: r.update(obs(t), ROSTER)
        events = [dict(player_id='a', timestamp=t, confirmed=True, source='official_play_by_play', status=s)
                  for t,s in [(2,'out'), (4,'in')]]
        self.assertEqual(r.presence(5, [], 0, substitution_events=events)[0]['court_state'], 'confirmed_on_court')

    def test_nonfinite_confidence_does_not_resolve(self):
        r = IdentityResolver()
        for t in [0, 1, 2]: result = r.update(obs(t, jersey_score=float('nan')), ROSTER)
        self.assertEqual(result['identity'], 'unknown')
