import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
import cv2
import numpy as np
import video_identity_pipeline as pipeline


class PipelineRegressions(unittest.TestCase):
    def test_pipeline_cli_filters_mixed_evidence_and_persists_human_review(self):
        # Substitute only external detector inference; exercise actual file IO, resolver and queues.
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);frames=root/'frames';frames.mkdir()
            for index in [0,1]:
                cv2.imencode('.jpg',np.zeros((80,120,3),np.uint8))[1].tofile(str(frames/f'{index}.jpg'))
            (root/'model.pt').write_bytes(b'test detector fixture')
            (root/'roster.json').write_text(json.dumps([{'player_id':'p'}]))
            (root/'reviews.json').write_text(json.dumps([{'shot_id':0,'track_id':1,'timestamp':0,'identity_evidence':[{'type':'human_review','reviewer':'fixture','player_id':'p','timestamp':0,'confirmed':True}]}]))
            (root/'ultralytics.py').write_text('''import numpy as np
from types import SimpleNamespace
class Tensor:
 def __init__(self,value):self.value=np.array(value)
 def __getitem__(self,index):return Tensor(self.value[index])
 def item(self):return self.value.item()
 def cpu(self):return self
 def numpy(self):return self.value
class YOLO:
 def __init__(self,path):self.predictor=SimpleNamespace(trackers=[])
 def track(self,*args,**kwargs):
  boxes=[SimpleNamespace(cls=Tensor(0),id=Tensor(i),conf=Tensor(.9),xyxy=Tensor([[x,0,x+30,70]])) for i,x in [(1,0),(2,40)]]
  return [SimpleNamespace(boxes=boxes,names={0:'person'},keypoints=None)]
''')
            env=dict(os.environ,PYTHONPATH=str(root))
            result=subprocess.run([sys.executable,str(Path(pipeline.__file__)),'--frames-dir',str(frames),'--model',str(root/'model.pt'),'--out',str(root/'run'),'--roster',str(root/'roster.json'),'--identity-evidence',str(root/'reviews.json'),'--width','120'],env=env,capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            manifest=json.loads((root/'run/run_manifest.json').read_text())
            self.assertEqual(manifest['detections'],4)
            self.assertEqual(manifest['review_items'],2)
            self.assertEqual(manifest['review_rate'],.5)
            queue=[json.loads(x) for x in (root/'run/review_queue.jsonl').read_text().splitlines()]
            self.assertEqual([r['track_id'] for r in queue],[2,2])

    def test_ffmpeg_discovery_on_path(self):
        with tempfile.TemporaryDirectory() as td:
            exe=Path(td)/('ffmpeg.exe' if os.name=='nt' else 'ffmpeg')
            exe.write_text('fixture')
            exe.chmod(0o755)
            from unittest.mock import patch
            with patch.dict(os.environ,{'PATH':td}):
                self.assertEqual(Path(pipeline.find_executable('ffmpeg')).resolve(),exe.resolve())

    def test_review_queue_filters_confirmed_rows(self):
        row={'track_id':1,'identity_result':{'identity':'p','identity_status':'human_confirmed','evidence_score':1,'review_reasons':[]}}
        self.assertEqual(pipeline.review_reasons(row),[])
        row['identity_result']['identity']='unknown'
        self.assertIn('unknown_identity',pipeline.review_reasons(row))
        row['track_id']=None
        self.assertIn('untracked_detection',pipeline.review_reasons(row))

    def test_color_map_is_never_team_confirmation(self):
        row=pipeline.team_evidence({'jersey_color':'white'},{'white':{'team':'HOU','score':1}})
        self.assertIsNone(row['team'])
        self.assertEqual(row['team_score'],0)
        self.assertEqual(row['team_candidates'][0]['team'],'HOU')

    def test_shoes_are_explicitly_unreliable_proxy(self):
        result=pipeline.visual_features(np.full((120,40,3),255,np.uint8))
        self.assertEqual(result['shoe_evidence_status'],'unreliable_bbox_proxy')
        self.assertNotIn('shoe_color',result)

    def test_frames_numeric_order_and_missing_frame_timestamps(self):
        with tempfile.TemporaryDirectory() as td:
            for index in [10,2,0]:
                cv2.imencode('.jpg',np.zeros((40,80,3),np.uint8))[1].tofile(str(Path(td)/f'frame_{index}.jpg'))
            frames=list(pipeline.directory_frames(td,fps=2.5,start=3,width=80))
            self.assertEqual([x[0] for x in frames],[0,2,10])
            self.assertEqual([x[1] for x in frames],[3,3.8,7])

    def test_frames_help_is_real_cli_entry(self):
        result=subprocess.run([sys.executable,str(Path(pipeline.__file__)),'--help'],capture_output=True,text=True)
        self.assertEqual(result.returncode,0)
        self.assertIn('--frames-dir',result.stdout)


if __name__=='__main__':unittest.main()
