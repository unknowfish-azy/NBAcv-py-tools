import unittest,sys,tempfile,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from skeleton_labeler import *
from identity_evidence import IdentityResolver
class ReviewRegression(unittest.TestCase):
 def test_missing_tail(self):
  r=detect_temporal_jumps([{'frame':1,'track_id':1,'keypoints':[[0,0,2]]*17},{'frame':2,'track_id':1,'keypoints':[[0,0,2]]*16}])
  self.assertEqual(r[1]['status'],'review')
 def test_one_joint_jump(self):
  r=detect_temporal_jumps([{'frame':1,'track_id':1,'keypoints':[[0,0,2]]*17},{'frame':2,'track_id':1,'keypoints':[[0,0,2]]*16+[[100,0,2]]}],20)
  self.assertEqual(r[1]['status'],'review')
 def test_no_track_not_pass(self):
  self.assertEqual(detect_temporal_jumps([{'frame':1,'keypoints':[[0,0,2]]*17}])[0]['temporal_status'],'NOT_RUN')
 def test_polygon_not_pose(self):
  r=parse_labelme({'imageWidth':100,'imageHeight':100,'shapes':[{'shape_type':'polygon','points':[[1,2]]*17}]})
  self.assertEqual(r['people'],[])
 def test_bad_point_preserved(self):
  r=parse_labelme({'imageWidth':100,'imageHeight':100,'shapes':[{'shape_type':'points','points':[[1,2]]*17+[None]}]})
  self.assertEqual(r['people'][0]['status'],'invalid')
 def test_number_types_and_threshold(self):
  roster=[{'player_id':'p','team':'HOU','jersey_number':'7'}]
  def run(threshold):
   m=IdentityResolver(min_jersey=threshold)
   for t in [0,1,2]:r=m.update({'timestamp':t,'track_id':1,'team':' hou ','team_score':.9,'jersey_number':7.0,'jersey_score':.85},roster)
   return r
  self.assertEqual(run(.8)['identity'],'p');self.assertEqual(run(.9)['identity'],'unknown')
 def test_cli_connected(self):
  from run_cv_tools import skeleton_cmd
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'in.json';out=Path(td)/'out.json'
   p.write_text(json.dumps([{'frame':1,'track_id':1,'keypoints':[[0,0,2]]*17},{'frame':2,'track_id':1,'keypoints':[[100,0,2]]*17}]))
   skeleton_cmd(p,out,17)
   r=json.loads(out.read_text())
   self.assertEqual(r['files'][0]['temporal'][1]['status'],'review')

 def test_temporal_speed_uses_timestamp_interval(self):
  rows=[{'frame':1,'timestamp_s':0.0,'track_id':1,'keypoints':[[0,0,2]]*17},
        {'frame':2,'timestamp_s':0.4,'track_id':1,'keypoints':[[100,0,2]]*17}]
  r=detect_temporal_jumps(rows,max_displacement=50,max_speed=300)
  self.assertEqual(r[1]['temporal_status'],'PASS')
  rows[1]['timestamp_s']=0.01
  self.assertEqual(detect_temporal_jumps(rows,max_displacement=50,max_speed=300)[1]['status'],'review')

 def test_temporal_gap_is_not_compared(self):
  rows=[{'frame':1,'timestamp_s':0.0,'track_id':1,'keypoints':[[0,0,2]]*17},
        {'frame':2,'timestamp_s':5.0,'track_id':1,'keypoints':[[1000,0,2]]*17}]
  r=detect_temporal_jumps(rows,max_displacement=50,max_speed=300,max_gap=1.0)
  self.assertIn('track_gap',r[1]['review_reasons'])
  self.assertEqual(r[1]['temporal_status'],'NOT_RUN')

 def test_yolo_confidence_is_preserved_separately(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'pose.json'
   p.write_text(json.dumps([{'track_id':1,'kpts':[[1,2,.95]]*16+[[3,4,.31]],'image_width':100,'image_height':100}]))
   row=normalize_file(p)['rows'][0]
   self.assertEqual(row['keypoint_confidence'],[.95]*16+[.31])
   self.assertNotEqual(row['status'],'invalid')
   self.assertEqual(row['keypoints'][0][2],0)

 def test_speed_cli_is_connected(self):
  import subprocess
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'pose.json';out=Path(td)/'out.json'
   p.write_text(json.dumps([{'track_id':1,'frame':i,'timestamp_s':t,'keypoints':[[x,0,2]]*17} for i,t,x in [(0,0,0),(1,.4,100)]]))
   result=subprocess.run([sys.executable,str(Path(__file__).resolve().parents[1]/'run_cv_tools.py'),'skeleton',str(p),str(out),'--max-speed','300'],capture_output=True,text=True)
   self.assertEqual(result.returncode,0,result.stderr)
   self.assertEqual(json.loads(out.read_text())['files'][0]['temporal'][1]['temporal_status'],'PASS')

 def test_confidence_survives_normalization_roundtrip(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'pose.json'
   p.write_text(json.dumps([{'track_id':1,'keypoint_format':'xy_confidence','keypoints':[[1,2,.95]]*17}]))
   first=normalize_file(p)
   p.write_text(json.dumps(first))
   second=normalize_file(p)
   self.assertEqual(second['rows'][0]['keypoint_confidence'],[.95]*17)

 def test_timestamp_only_rows_are_sorted(self):
  rows=[{'timestamp_s':t,'track_id':1,'keypoints':[[100*t,0,2]]*17} for t in [1,0]]
  result=detect_temporal_jumps(rows,max_speed=200)
  self.assertEqual([r['timestamp_s'] for r in result],[0,1])
  self.assertEqual(result[-1]['temporal_status'],'PASS')

 def test_speed_mode_replaces_legacy_per_frame_displacement(self):
  rows=[{'timestamp_s':0,'track_id':1,'keypoints':[[0,0,2]]*17},
        {'timestamp_s':1,'track_id':1,'keypoints':[[80,0,2]]*17}]
  self.assertEqual(detect_temporal_jumps(rows,max_displacement=50,max_speed=100)[1]['temporal_status'],'PASS')

 def test_incompatible_joint_names_are_not_overwritten(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'pose.json'
   p.write_text(json.dumps([{'keypoints':[[1,2,2]]*17,'joint_names':list(reversed(COCO17))}]))
   self.assertEqual(normalize_file(p)['rows'][0]['status'],'invalid')

 def test_labelme_directory_uses_filename_frames_for_temporal_gate(self):
  from run_cv_tools import skeleton_cmd
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);out=root/'out.json'
   for frame,x in [(1,0),(2,100)]:
    data={'imageWidth':200,'imageHeight':200,'shapes':[{'shape_type':'points','group_id':7,'points':[[x,0,2]]*17}]}
    (root/f'frame_{frame:04}.json').write_text(json.dumps(data))
   skeleton_cmd(root,out,input_format='labelme',max_displacement=20,fps=1,group_id_is_track=True)
   result=json.loads(out.read_text())
   temporal=[item for f in result['files'] for item in f['temporal']]
   self.assertTrue(any(item['temporal_status']=='REVIEW' for item in temporal))
