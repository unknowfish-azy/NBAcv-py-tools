import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from identity_evidence import IdentityResolver
from skeleton_labeler import COCO17, normalize_file
from run_cv_tools import skeleton_cmd, identity_cmd
from player_identity_cv import build_identity_report

ROSTER=[{'player_id':'a','team':'HOU','jersey_number':1}]
def observation(t, **extra):
    return dict(timestamp=t,track_id=1,**extra)
def review(t=0, **extra):
    return dict(type='human_review',timestamp=t,reviewer='tester',player_id='a',confirmed=True,**extra)

class Contracts(unittest.TestCase):
    def test_revoke_and_replayed_evidence_stays_revoked(self):
        r=IdentityResolver()
        evidence=review(evidence_id='r1')
        r.update(observation(0,identity_evidence=[evidence]),ROSTER)
        revoke={'type':'human_review_revoke','evidence_id':'r1','reviewer':'tester','timestamp':1}
        result=r.update(observation(1,identity_evidence=[revoke,evidence]),ROSTER)
        self.assertEqual(result['identity'],'unknown')
        self.assertEqual(r.update(observation(2,identity_evidence=[evidence]),ROSTER)['identity'],'unknown')

    def test_long_gap_resets_human_and_ocr(self):
        r=IdentityResolver(max_track_gap=2)
        r.update(observation(0,identity_evidence=[review()]),ROSTER)
        self.assertEqual(r.update(observation(3),ROSTER)['identity'],'unknown')

    def test_visual_model_review_is_not_human_confirmation(self):
        result=IdentityResolver().update(observation(0,identity_evidence=[review(reviewer_kind='model')]),ROSTER)
        self.assertEqual(result['identity'],'unknown')
        self.assertIn('model_review_requires_human',result['review_reasons'])

    def test_report_accepts_wrapped_legacy_and_flat_rows(self):
        rows=[{'resolution':{'track_id':1,'timestamp':0,'identity':'a'}}]
        self.assertEqual(build_identity_report(rows)['resolved_observations'],1)

    def test_invalid_batch_config_fails_before_parsing(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'1.json').write_text('{}')
            with patch('run_cv_tools.normalize_file',side_effect=AssertionError('input was parsed')):
                with self.assertRaises(ValueError):skeleton_cmd(p,p/'out.json',max_speed=-1)

    def test_aliases_preserve_order_without_guessing(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'pose.json'
            names=[n.upper().replace('LEFT_','L_').replace('RIGHT_','R_') for n in COCO17]
            p.write_text(json.dumps([{'joint_names':names,'keypoints':[[1,2,2]]*17}]))
            result=normalize_file(p)['rows'][0]
            self.assertNotEqual(result['status'],'invalid')
            self.assertEqual(result['joint_names'],COCO17)

    def test_labelme_mapping_2d_and_duplicate_identity(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)
            for frame,x in [(1,0),(2,100),(3,110)]:
                shapes=[{'label':'Amen','shape_type':'points','group_id':frame,'points':[[x,0]]*17}]
                if frame==3:shapes.append(dict(shapes[0]))
                (p/f'frame_{frame}.json').write_text(json.dumps({'shapes':shapes,'imageWidth':200,'imageHeight':200}))
            mapping=p/'mapping.txt';mapping.write_text(json.dumps({'Amen':'amen'}))
            skeleton_cmd(p,p/'out.json',fps=2.5,max_speed=200,track_map=mapping,compare_unmarked_points=True)
            files=json.loads((p/'out.json').read_text())['files']
            self.assertEqual(files[1]['temporal'][0]['temporal_status'],'REVIEW')
            self.assertIn('duplicate_track_in_frame',files[2]['temporal'][0]['review_reasons'])
            self.assertEqual(files[0]['people'][0]['keypoints'][0][2],0)

    def test_gallery_changes_threshold_decision_but_not_alone(self):
        for gallery,expected in [([], 'unknown'),([{'player_id':'a','features':{'appearance_histogram':[1,0]}}],'a')]:
            r=IdentityResolver(min_confidence=.88,gallery=gallery)
            for t in [0,1,2]:
                result=r.update(observation(t,team='HOU',team_score=.85,jersey_number=1,jersey_score=.85,features={'appearance_histogram':[1,0]}),ROSTER)
            self.assertEqual(result['identity'],expected)
