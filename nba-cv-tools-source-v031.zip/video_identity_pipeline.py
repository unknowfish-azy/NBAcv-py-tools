"""Local frame/video evidence extraction. Scores are uncalibrated heuristics."""
import argparse
import collections
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

import cv2
import numpy as np
from identity_evidence import IdentityResolver, canonical_number
from skeleton_labeler import detect_temporal_jumps


def color(image):
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    h, s, v = np.median(hsv.reshape(-1, 3), axis=0)
    if v < 55:
        return 'black'
    if s < 45:
        return 'white' if v > 180 else 'gray'
    return ('red' if h < 12 or h > 168 else 'orange' if h < 25 else
            'yellow' if h < 38 else 'green' if h < 85 else 'blue' if h < 135 else 'purple')


def visual_features(crop):
    height, width = crop.shape[:2]
    if height < 32 or width < 12:
        return {'status': 'insufficient_pixels'}
    torso = crop[int(height*.2):int(height*.6), int(width*.2):int(width*.8)]
    shoe_proxy = crop[int(height*.88):, int(width*.1):int(width*.9)]
    def histogram(region):
        hist = cv2.calcHist([cv2.cvtColor(region, cv2.COLOR_BGR2HSV)], [0, 1],
                           None, [12, 4], [0, 180, 0, 256]).flatten()
        return (hist / max(float(hist.sum()), 1)).tolist()
    hist = histogram(torso)
    return {'jersey_histogram': hist, 'appearance_histogram': hist,
            'status': 'measured_proxy', 'jersey_color': color(torso),
            'shoe_color_proxy': color(shoe_proxy) if height >= 100 else None,
            'shoe_histogram_proxy': histogram(shoe_proxy) if height >= 100 else [],
            'shoe_evidence_status': 'unreliable_bbox_proxy',
            'height_width_ratio': height / width, 'real_height_cm': None}


def team_evidence(features, team_map):
    """Legacy color maps retrieve candidates only: white does not establish team."""
    value = team_map.get(features.get('jersey_color'), [])
    values = value if isinstance(value, list) else [value]
    candidates = [dict(team=v['team'], basis='color_only', score=v.get('score', 0))
                  for v in values if isinstance(v, dict) and v.get('team')]
    return {'team': None, 'team_score': 0., 'team_candidates': candidates}


def review_reasons(row, threshold=.8):
    result = row.get('identity_result') or {}
    reasons = list(result.get('review_reasons') or [])
    if row.get('track_id') is None:
        reasons.append('untracked_detection')
    if result.get('identity', 'unknown') == 'unknown':
        reasons.append('unknown_identity')
    elif result.get('evidence_score', 0) < threshold:
        reasons.append('low_evidence_score')
    numbers = {canonical_number(c.get('text')) for c in row.get('ocr_candidates', [])
               if c.get('score', 0) >= .8}
    numbers.discard(None)
    if len(numbers) > 1:
        reasons.append('conflicting_ocr_candidates')
    if row.get('temporal_status') == 'REVIEW':
        reasons.append('temporal_jump')
    return list(dict.fromkeys(reasons))


def _resize(image, width):
    height = max(2, round(image.shape[0] * width / image.shape[1] / 2) * 2)
    return cv2.resize(image, (width, height))


def directory_frames(directory, fps, start=0, width=960):
    """Trailing filename number is the sample index; gaps retain elapsed time."""
    paths = [p for p in Path(directory).iterdir() if p.suffix.lower() in ('.jpg', '.jpeg', '.png', '.bmp')]
    if not paths:
        raise ValueError('No supported images in frames directory')
    def index(path):
        numbers = re.findall(r'\d+', path.stem)
        return int(numbers[-1]) if numbers else None
    numbered = [index(p) for p in paths]
    if any(n is None for n in numbered):
        if any(n is not None for n in numbered):
            raise ValueError('Mixed numbered and unnumbered frames are ambiguous')
        pairs = list(enumerate(sorted(paths)))
    else:
        if len(set(numbered)) != len(paths):
            raise ValueError('Duplicate numeric frame indexes')
        pairs = sorted(zip(numbered, paths))
    first_index = pairs[0][0]
    for frame_index, path in pairs:
        image = cv2.imdecode(np.fromfile(str(path), np.uint8), cv2.IMREAD_COLOR)
        if image is None:
            raise ValueError(f'Cannot decode image: {path}')
        yield frame_index, start + (frame_index-first_index)/fps, _resize(image, width), str(path.resolve())


def find_executable(name, explicit=None):
    found = shutil.which(explicit or name)
    if found:
        return found
    if explicit and Path(explicit).is_file():
        return str(Path(explicit).resolve())
    raise ValueError(f'{name} not found; install on PATH or supply --{name}')


def video_frames(args, output, state):
    ffmpeg = find_executable('ffmpeg', args.ffmpeg)
    sibling = Path(ffmpeg).with_name('ffprobe.exe' if Path(ffmpeg).suffix == '.exe' else 'ffprobe')
    ffprobe = find_executable('ffprobe', args.ffprobe or (str(sibling) if sibling.is_file() else None))
    probe = subprocess.run([ffprobe, '-v', 'error', '-select_streams', 'v:0',
                            '-show_entries', 'stream=width,height', '-of', 'json', args.video],
                           capture_output=True, text=True, check=True)
    meta = json.loads(probe.stdout)['streams'][0]
    width, height = args.width, max(2, round(meta['height']*args.width/meta['width']/2)*2)
    command = [ffmpeg, '-v', 'error', '-ss', str(args.start), '-i', args.video,
               '-t', str(args.seconds), '-vf', f'scale={width}:{height},fps={args.fps}',
               '-f', 'rawvideo', '-pix_fmt', 'bgr24', 'pipe:1']
    state['decode_command'] = command
    with (output/'decode.log').open('wb') as log:
        proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=log)
        complete = False
        try:
            count = 0
            while True:
                buffer = bytearray()
                while len(buffer) < width*height*3:
                    chunk = proc.stdout.read(width*height*3-len(buffer))
                    if not chunk:
                        break
                    buffer.extend(chunk)
                if not buffer:
                    complete = True
                    break
                if len(buffer) != width*height*3:
                    raise ValueError('Truncated FFmpeg raw frame')
                frame = np.frombuffer(buffer, np.uint8).reshape(height, width, 3).copy()
                yield count, args.start+count/args.fps, frame, str(Path(args.video).resolve())
                count += 1
        finally:
            proc.stdout.close()
            if not complete and proc.poll() is None:
                proc.terminate()
            try:
                state['ffmpeg_exit'] = proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                state['ffmpeg_exit'] = proc.wait(timeout=10)
            state['decode_stopped_early'] = not complete
        if state['ffmpeg_exit'] != 0:
            raise RuntimeError(f"FFmpeg failed ({state['ffmpeg_exit']}); see decode.log")


def read_json(path, default):
    return json.loads(Path(path).read_text(encoding='utf-8-sig')) if path else default


def ocr_candidates(reader, crop):
    if reader is None or crop.shape[0] < 64:
        return []
    roi = crop[int(len(crop)*.18):int(len(crop)*.65)]
    candidates = []
    for polygon, text, confidence in reader.readtext(roi, allowlist='0123456789', detail=1):
        if text.isdigit() and len(text) <= 2:
            candidates.append({'text': text, 'score': float(confidence),
                               'engine': 'easyocr', 'roi_polygon': np.asarray(polygon).tolist(),
                               'roi_offset_in_crop': [0, int(len(crop)*.18)]})
    return candidates


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--video')
    source.add_argument('--frames-dir')
    parser.add_argument('--model', required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--start', type=float, default=0)
    parser.add_argument('--seconds', type=float, default=10)
    parser.add_argument('--max-frames', type=int)
    parser.add_argument('--fps', type=float, default=5)
    parser.add_argument('--width', type=int, default=960)
    parser.add_argument('--ocr', action='store_true')
    parser.add_argument('--roster')
    parser.add_argument('--gallery')
    parser.add_argument('--team-map')
    parser.add_argument('--identity-evidence', help='JSON rows keyed by shot_id, track_id and timestamp')
    parser.add_argument('--substitutions')
    parser.add_argument('--ffmpeg')
    parser.add_argument('--ffprobe')
    parser.add_argument('--min-confidence', type=float, default=.8)
    return parser.parse_args(argv)


def run(args):
    if any(not math.isfinite(x) or x <= 0 for x in (args.seconds, args.fps)) or args.start < 0 or not math.isfinite(args.start) or args.width < 64:
        raise ValueError('Invalid sampling bounds')
    if args.max_frames is not None and args.max_frames <= 0:
        raise ValueError('max-frames must be positive')
    model_path = Path(args.model)
    if not model_path.is_file():
        raise ValueError('Local model file does not exist')
    if not Path(args.video or args.frames_dir).exists():
        raise ValueError('Input does not exist')
    roster = read_json(args.roster, [])
    roster = roster.get('players') if isinstance(roster, dict) else roster
    resolver = IdentityResolver(gallery=read_json(args.gallery, []), min_confidence=args.min_confidence)
    team_map = read_json(args.team_map, {})
    annotations = read_json(args.identity_evidence, [])
    substitutions = read_json(args.substitutions, [])
    if not isinstance(annotations, list) or not isinstance(roster, list):
        raise ValueError('Evidence and roster must be arrays')
    from ultralytics import YOLO
    model = YOLO(str(model_path))
    reader = None
    if args.ocr:
        import easyocr
        reader = easyocr.Reader(['en'], gpu=False, download_enabled=False)
    output = Path(args.out)
    output.mkdir(parents=True, exist_ok=False)
    state = {'ffmpeg_exit': None}
    started = time.monotonic()
    trajectories = collections.defaultdict(list)
    reason_counts = collections.Counter()
    pose_rows = []
    count = detections = review_count = shot = ocr_count = 0
    previous = None
    frames = directory_frames(args.frames_dir, args.fps, args.start, args.width) if args.frames_dir else video_frames(args, output, state)
    error = None
    try:
        with (output/'evidence.jsonl').open('w', encoding='utf8') as evidence_file, \
                (output/'review_queue.jsonl').open('w', encoding='utf8') as review_file, \
                (output/'presence.jsonl').open('w', encoding='utf8') as presence_file:
            for index, timestamp, frame, source in frames:
                height, width = frame.shape[:2]
                gray = cv2.resize(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY), (64, 36))
                cut = previous is not None and float(np.mean(np.abs(gray.astype(float)-previous))) > 45
                if cut:
                    shot += 1
                    for tracker in getattr(model.predictor, 'trackers', []):
                        tracker.reset()
                previous = gray
                result = model.track(frame, persist=True, tracker='bytetrack.yaml', verbose=False, conf=.3)[0]
                visible = []
                for box_index, box in enumerate(result.boxes):
                    label = str(result.names[int(box.cls.item())]).lower()
                    if not any(token in label for token in ('person', 'player')):
                        continue
                    x1, y1, x2, y2 = map(int, box.xyxy[0].cpu().numpy())
                    x1, y1, x2, y2 = max(0,x1), max(0,y1), min(width,x2), min(height,y2)
                    if x2 <= x1 or y2 <= y1:
                        continue
                    tid = int(box.id.item()) if box.id is not None else None
                    crop = frame[y1:y2, x1:x2]
                    features = visual_features(crop)
                    if result.keypoints is not None:
                        keypoints = result.keypoints.data[box_index].cpu().numpy()
                        features['pose_keypoints_xy_confidence'] = keypoints.tolist()
                        pose_rows.append({'frame':index,'timestamp_s':timestamp,'shot_id':shot,'track_id':tid,
                                          'keypoints':[list(point[:2])+[0] for point in keypoints.tolist()],
                                          'keypoint_confidence':[float(point[2]) for point in keypoints.tolist()],
                                          'visibility_source':'model_confidence_separate'})
                    candidates = ocr_candidates(reader, crop) if count % max(1,round(args.fps)) == 0 else []
                    ocr_count += sum(c['score'] >= .8 for c in candidates)
                    best = max(candidates, key=lambda c:c['score']) if candidates else {}
                    row = {'frame': index, 'timestamp': timestamp, 'timestamp_s': timestamp,
                           'source': source, 'shot_id': shot, 'track_id': tid,
                           'bbox': [x1,y1,x2,y2], 'detector_score': float(box.conf.item()),
                           'features': features, 'jersey_number': best.get('text'),
                           'jersey_score': best.get('score',0), 'ocr_candidates': candidates,
                           'evidence_source': 'easyocr' if candidates else 'visual_only'}
                    row.update(team_evidence(features, team_map))
                    matched = [a for a in annotations if a.get('shot_id') == shot and a.get('track_id') == tid
                               and isinstance(a.get('timestamp'), (int,float)) and abs(a['timestamp']-timestamp) < 1e-6]
                    row['identity_evidence'] = [e for a in matched for e in a.get('identity_evidence', [])]
                    explicit = [a for a in matched if a.get('team') and a.get('team_source') in ('human_review','official') and a.get('reviewer')]
                    if len({a['team'] for a in explicit}) == 1:
                        row.update(team=explicit[0]['team'],team_score=.999,team_evidence=explicit[0])
                    row['identity_result'] = resolver.update(row, roster) if tid is not None else {'identity':'unknown','review_reasons':['untracked_detection']}
                    reasons = review_reasons(row, args.min_confidence)
                    if reasons:
                        review_file.write(json.dumps({'frame':index,'timestamp_s':timestamp,'shot_id':shot,'track_id':tid,'reasons':reasons})+'\n')
                        review_count += 1
                        reason_counts.update(reasons)
                    if tid is not None:
                        trajectories[f'{shot}:{tid}'].append({'timestamp_s':timestamp,'foot_pixel':[(x1+x2)/2,y2], 'body_ratio':features.get('height_width_ratio')})
                        visible.append(tid)
                    evidence_file.write(json.dumps(row, ensure_ascii=False, allow_nan=False)+'\n')
                    detections += 1
                    cv2.rectangle(frame,(x1,y1),(x2,y2),(0,220,0),1)
                    cv2.putText(frame,f'T{tid} #{best.get("text","?")}',(x1,max(15,y1)),cv2.FONT_HERSHEY_SIMPLEX,.4,(0,255,255),1)
                presence_file.write(json.dumps({'timestamp_s':timestamp,'shot_id':shot,'visible_tracks':visible,
                                                'players':resolver.presence(timestamp,visible,shot_id=shot,substitution_events=substitutions)})+'\n')
                if count < 5:
                    cv2.imencode('.jpg',frame)[1].tofile(str(output/f'review_{count:04}.jpg'))
                count += 1
                evidence_file.flush();review_file.flush();presence_file.flush()
                print(f'frames={count} detections={detections} review={review_count}',flush=True)
                if args.max_frames and count >= args.max_frames:
                    break
            if count == 0:
                raise ValueError('No frames decoded')
            temporal = detect_temporal_jumps(pose_rows, max_displacement=50, max_speed=300, max_gap=2.0) if pose_rows else []
            temporal_reviews = [item for item in temporal if item.get('temporal_status') == 'REVIEW']
            for item in temporal_reviews:
                reasons = item.get('review_reasons') or ['temporal_jump']
                review_file.write(json.dumps({'frame':item.get('frame'),'timestamp_s':item.get('timestamp_s'),
                                              'shot_id':item.get('shot_id',0),'track_id':item.get('track_id'),
                                              'reasons':['temporal_jump' if isinstance(reason,dict) else reason for reason in reasons]})+'\n')
                review_count += 1
                reason_counts.update('temporal_jump' if isinstance(reason,dict) else reason for reason in reasons)
    except Exception as exc:
        error = str(exc)
        raise
    finally:
        frames.close()
        with model_path.open('rb') as model_file:
            model_hash = hashlib.file_digest(model_file,'sha256').hexdigest() if hasattr(hashlib,'file_digest') else hashlib.sha256(model_file.read()).hexdigest()
        manifest = {'input':str(Path(args.video or args.frames_dir).resolve()),'input_mode':'frames' if args.frames_dir else 'video',
                    'model':str(model_path.resolve()),'model_sha256':model_hash,
                    'frames':count,'detections':detections,'review_items':review_count,
                    'review_rate':review_count/detections if detections else 0,
                    'review_reasons':dict(reason_counts),'reliable_ocr_candidates':ocr_count,
                    'elapsed_s':time.monotonic()-started,'sample_fps':args.fps,'start':args.start,
                    'ocr_enabled':args.ocr,'status':'FAILED' if error else 'ENGINEERING_ONLY',
                    'accuracy':'NOT_EVALUATED','error':error,**state,
                    'notes':['appearance/shoe/body are uncalibrated proxies','color does not establish team',
                             'no face recognition or true height estimate','missing screen detection does not prove substitution',
                             'frame timestamps assume filename numbers index the declared sample fps']}
        (output/'trajectories.json').write_text(json.dumps(dict(trajectories)),encoding='utf8')
        (output/'run_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(manifest,ensure_ascii=False),flush=True)
    return manifest


def main(argv=None):
    try:
        run(parse_args(argv))
        return 0
    except (ValueError,OSError,RuntimeError,subprocess.SubprocessError) as exc:
        print(json.dumps({'status':'ERROR','error':str(exc)},ensure_ascii=False),file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
