# AI 预标 + 真人抽检

此通道记录人对指定范围的抽检背书，不代表真人逐帧标注，不估计整批准确率，也不认证签字人的真实身份。不要伪造 reviewer 或抽检记录。

观察行必须有 timestamp、video_id、shot_id、track_id。下面是假设样例，替换成真实记录后才能使用：

```json
{
  "timestamp": 0, "video_id": "game-1", "shot_id": 0, "track_id": 1,
  "identity_evidence": [{
    "type": "human_review", "reviewer_kind": "ai_assisted",
    "reviewer": "vision_model", "human_reviewer": "实际抽检人",
    "player_id": "amen_thompson", "timestamp": 0,
    "evidence_id": "audit-001", "confirmed": true,
    "spot_check": {
      "approved": true, "passed": 3, "sampled": 3, "required": 3,
      "population": 30, "source": "实际抽检记录.json",
      "sampling_method": "random",
      "scope": {"video_id": "game-1", "shot_id": 0, "track_id": 1, "start_s": 0, "end_s": 10}
    }
  }]
}
```

`required` 是提交方声明的抽检要求；工具验证 0 < required <= passed == sampled <= population，不把固定三张或某个比例视为统计准确率保证。所有抽检样本必须通过。source 必须指向可追溯记录；当前只验证字段完整性，不读取该记录核实签字。

通过时状态为 `ai_confirmed_spot_checked`，分数是未校准的规则分数。作用域不匹配、记录不完整或抽检有失败均拒绝。仍遵守 300 秒证据寿命、默认 2 秒轨迹断档清证据及撤销。证据到期或轨迹断档后输出 `identity=unknown, identity_status=reconfirm_needed`，进入高优先级队列。

撤销：同视频/镜头/轨迹的一行 identity_evidence 提供 `type=human_review_revoke`、evidence_id、reviewer、timestamp。撤销后重放同一 evidence_id 无效。重新审核使用新的 evidence_id 与真实审核时间。

两个 JSON CLI 均生成 `<输出文件主名>.review_queue.jsonl`，schema 为 nba.review.v1。字段含 kind、source_file、frame、track_id、timestamp_s、status、priority、reasons；目标文件已存在即失败，不覆盖。

group_id 映射使用 `{"group_id":{"9":"amen"}}`；标签映射使用 `{"label":{"阿门汤普森":"amen"}}` 或兼容旧式平铺字典。group_id 必须本来就跨帧稳定，映射不能修复框序号的身份漂移。

`skeleton --suggest-speed` 输出相邻轨迹区间最大关节速度的 P99 × 1.2 建议；排除不完整骨架、无可见点、跨镜头及超 max-gap 区间。建议未校准，可能受镜头移动和坏标注影响，只用于辅助抽查，不自动应用。两列点默认 NOT_RUN/missing_visibility；显式 --compare-unmarked-points 会比较坐标但不会伪造 visibility。
