"""Conservative identity evidence; scores are NOT calibrated probabilities.

Only repeated, high-confidence team + jersey observations can produce a
provisional name. Appearance is a candidate retrieval cue only. Track IDs are
scoped to a shot; absence from video never establishes absence from the court.
"""
from collections import defaultdict
import math
import copy


def valid_spot_check(item, obs):
    """Validate declared human approval; this cannot authenticate a signer."""
    spot=item.get('spot_check')
    if not isinstance(spot,dict):return False
    for field in ('evidence_id','human_reviewer','reviewer'):
        if not isinstance(item.get(field),str) or not item[field].strip():return False
    if item['human_reviewer'].strip()==item['reviewer'].strip():return False
    counts=[spot.get(k) for k in ('passed','required','sampled','population')]
    if any(type(v) is not int for v in counts):return False
    passed,required,sampled,population=counts
    if not 0<required<=passed==sampled<=population:return False
    if spot.get('approved') is not True:return False
    if any(not isinstance(spot.get(k),str) or not spot[k].strip() for k in ('source','sampling_method')):return False
    scope=spot.get('scope')
    if not isinstance(scope,dict):return False
    start,end=scope.get('start_s'),scope.get('end_s')
    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in (start,end)):return False
    if not 0<=start<=obs['timestamp']<=end:return False
    return all(k in scope and k in obs and scope[k]==obs[k] for k in ('track_id','shot_id','video_id'))


def histogram_similarity(a, b):
    if not a or not b or len(a) != len(b):
        return 0.0
    try:
        a, b = [float(x) for x in a], [float(x) for x in b]
    except (ValueError, TypeError):
        return 0.0
    if any(not math.isfinite(x) or x < 0 for x in a + b):
        return 0.0
    na, nb = sum(a), sum(b)
    if na <= 0 or nb <= 0:
        return 0.0
    return max(0.0, min(1.0, 1.0 - sum(abs(x/na-y/nb) for x, y in zip(a, b))/2))


def canonical_number(value):
    if value is None or isinstance(value,bool): return None
    text=str(value).strip()
    if text=='00': return '00'
    try:
        number=float(text)
        if not math.isfinite(number) or number!=int(number) or not 0<=number<=99:return None
        return str(int(number))
    except (ValueError,TypeError):return None

def _score(value):
    try:
        value = float(value)
        return max(0.0, min(.999, value)) if math.isfinite(value) else 0.0
    except (TypeError, ValueError):
        return 0.0


class IdentityResolver:
    def __init__(self, gallery=None, min_team=.8, min_jersey=.8,
                 min_repeats=3, min_interval=.25, min_confidence=.8,
                 max_human_duration=300.0, max_track_gap=2.0):
        self.gallery = gallery or []
        self.min_team, self.min_jersey = min_team, min_jersey
        self.min_repeats = max(2, min_repeats)
        self.min_interval = max(.001, min_interval)
        if isinstance(min_confidence, bool) or not isinstance(min_confidence, (int,float)) or not math.isfinite(min_confidence) or not 0 <= min_confidence <= 1:
            raise ValueError('min_confidence must be finite in [0, 1]')
        self.min_confidence = float(min_confidence)
        if max_human_duration is not None and (isinstance(max_human_duration, bool) or not isinstance(max_human_duration, (int,float)) or not math.isfinite(max_human_duration) or max_human_duration <= 0):
            raise ValueError('max_human_duration must be positive or None')
        self.max_human_duration = max_human_duration
        if max_track_gap is not None and (isinstance(max_track_gap, bool) or not isinstance(max_track_gap,(int,float)) or not math.isfinite(max_track_gap) or max_track_gap <= 0):
            raise ValueError('max_track_gap must be positive or None')
        self.max_track_gap=max_track_gap
        self._evidence = defaultdict(list)
        self._last_seen={}
        self._segment_start={}
        self._revoked=defaultdict(set)
        self._reconfirm=defaultdict(set)
        self._results = {}
        self._roster = []

    def update(self, obs, roster):
        ts = obs.get('timestamp')
        if isinstance(ts,bool) or not isinstance(ts, (int, float)) or not math.isfinite(ts) or ts < 0:
            raise ValueError('timestamp must be finite nonnegative seconds')
        tid, shot, video = obs.get('track_id'), obs.get('shot_id', 0), obs.get('video_id')
        if tid is None:
            raise ValueError('track_id is required')
        if not isinstance(roster,list) or any(not isinstance(p,dict) for p in roster):raise ValueError('roster must be an array of objects')
        self._roster = roster
        key = (video,tid, shot)
        evidence = self._evidence[key]
        previous_ts = self._last_seen.get(key,-math.inf)
        if ts<previous_ts:raise ValueError('Track observations must be chronological')
        if self.max_track_gap is not None and previous_ts > -math.inf and ts - previous_ts > self.max_track_gap:
            if any(e.get('type')=='human_review' for e in evidence):self._reconfirm[key].add('track_gap_reconfirm')
            evidence.clear()
            self._segment_start[key]=ts
        self._last_seen[key]=ts
        reasons = []
        entries=obs.get('identity_evidence') or []
        if not isinstance(entries,list):raise ValueError('identity_evidence must be an array')
        revoked = self._revoked[key]
        for item in entries:
            if not isinstance(item,dict):raise ValueError('identity_evidence entries must be objects')
            if item.get('type') == 'human_review_revoke':
                rt=item.get('timestamp'); rid=item.get('evidence_id')
                if isinstance(rid,str) and rid and isinstance(item.get('reviewer'),str) and item['reviewer'].strip() and isinstance(rt,(int,float)) and not isinstance(rt,bool) and math.isfinite(rt) and 0<=rt<=ts:
                    revoked.add(rid)
                    self._reconfirm[key].add('human_review_revoked')
                    reasons.append('human_review_revoked')
                else:reasons.append('invalid_human_review_revocation')
        for e in evidence:
            if e.get('type')=='human_review' and self.max_human_duration is not None and ts-e['timestamp']>self.max_human_duration:self._reconfirm[key].add('human_review_expired')
            if e.get('reviewer_kind')=='ai_assisted' and not valid_spot_check(e,obs):self._reconfirm[key].add('spot_check_scope_ended')
        evidence[:]=[e for e in evidence if e.get('type')!='human_review' or (e.get('evidence_id') not in revoked and (self.max_human_duration is None or ts-e['timestamp']<=self.max_human_duration) and (e.get('reviewer_kind')!='ai_assisted' or valid_spot_check(e,obs)))]
        human = [e for e in evidence if e.get('type') == 'human_review' and e.get('evidence_id') not in revoked and
                 (self.max_human_duration is None or ts-e.get('timestamp', ts) <= self.max_human_duration)]
        for item in entries:
            if not isinstance(item, dict) or item.get('type') != 'human_review':
                continue
            reviewer, pid, hts = item.get('reviewer'), item.get('player_id'), item.get('timestamp')
            item_shot = item.get('shot_id', shot)
            item_video = item.get('video_id', video)
            item_track = item.get('track_id', tid)
            if item.get('evidence_id') in revoked:continue
            model_reviewer=isinstance(reviewer,str) and reviewer.lower() in ('zcode_visual_review','vision_model','ai_review') and item.get('reviewer_kind') != 'human'
            ai_assisted=item.get('reviewer_kind') == 'ai_assisted'
            ai_valid=ai_assisted and valid_spot_check(item,obs)
            if ai_assisted and not ai_valid:
                reasons.append('invalid_spot_check_approval');continue
            if item_shot != shot or item_video != video or item_track != tid or (item.get('reviewer_kind') == 'model') or (model_reviewer and not ai_valid):
                if item.get('reviewer_kind') == 'model' or model_reviewer: reasons.append('model_review_requires_human')
                continue
            if item.get('confirmed') is True and isinstance(reviewer, str) and reviewer.strip() and pid not in (None, '', 'unknown') and any(p.get('player_id')==pid for p in roster) and not isinstance(hts,bool) and isinstance(hts, (int, float)) and math.isfinite(hts) and self._segment_start.get(key,0) <= hts <= ts and (self.max_human_duration is None or ts-hts <= self.max_human_duration) and (not ai_assisted or ai_valid):
                entry=dict(type='human_review', reviewer=reviewer.strip(), reviewer_kind=item.get('reviewer_kind','human'), human_reviewer=item.get('human_reviewer'), spot_check=item.get('spot_check'), player_id=pid, timestamp=hts, confirmed=True, source=item.get('source', 'human_review'), evidence_id=item.get('evidence_id'))
                entry=copy.deepcopy(entry)
                if entry not in human:
                    human.append(entry)
                    evidence.append(entry)
            else:
                reasons.append('invalid_human_review_evidence')
        team = str(obs.get('team') or '').strip().upper()
        number = canonical_number(obs.get('jersey_number'))
        tc, jc = _score(obs.get('team_score')), _score(obs.get('jersey_score'))
        matches = [p for p in self._roster if team and number is not None
                   and str(p.get('team') or '').strip().upper() == team and canonical_number(p.get('jersey_number')) == number
                   and p.get('player_id') not in (None, '', 'unknown')]
        independent = not any(abs(e['timestamp']-ts) < self.min_interval for e in evidence if e.get('type')!='human_review')
        if len(matches) > 1:
            reasons.append('ambiguous_roster_match')
        if len(matches) == 1 and any(e.get('player_id') != matches[0]['player_id'] for e in evidence if e.get('type') != 'human_review'):
            reasons.append('conflicting_identity_evidence')
        if len(matches) == 1 and tc >= self.min_team and jc >= self.min_jersey and independent:
            evidence.append(dict(timestamp=ts, player_id=matches[0]['player_id'],
                                 weight=min(tc, jc), team=team, jersey_number=str(number),
                                 source=obs.get('evidence_source', 'unspecified_team_jersey'),
                                 frame=obs.get('frame')))
        groups = defaultdict(list)
        for e in evidence:
            if e.get('type')!='human_review':groups[e['player_id']].append(e)
        identity, score, identity_status = 'unknown', 0.0, 'unknown'
        if human:
            pids = {e['player_id'] for e in human}
            if len(pids) == 1:
                identity = next(iter(pids)); score = .98 if any(e.get('reviewer_kind')=='ai_assisted' for e in human) else 1.0
                identity_status = 'ai_confirmed_spot_checked' if any(e.get('reviewer_kind')=='ai_assisted' for e in human) else 'human_confirmed'
            else:
                reasons.append('conflicting_human_review_evidence')
        if len(groups) > 1:
            reasons.append('conflicting_identity_evidence')
        elif groups and not human:
            pid, rows = next(iter(groups.items()))
            score = min(.99, sum(e['weight'] for e in rows)/len(rows) * min(1, len(rows)/self.min_repeats))
            team_score = sum(e['weight'] for e in rows) / len(rows)
            score = max(score, team_score * min(1, len(rows) / self.min_repeats))
            if identity == 'unknown' and len(rows) >= self.min_repeats and not reasons and score >= self.min_confidence:
                identity = pid
                identity_status = 'provisional'
        candidates = [dict(player_id=pid, score=round(sum(e['weight'] for e in rows)/len(rows), 4),
                           basis='team_jersey', observations=len(rows)) for pid, rows in groups.items()]
        features = obs.get('features') or {}
        appearance_candidates = []
        for item in self.gallery:
            similarities = []
            for field in ('appearance_histogram', 'jersey_histogram'):
                sim = histogram_similarity(features.get(field, []), (item.get('features') or {}).get(field, []))
                if sim > 0:
                    similarities.append(sim)
                    break  # The torso histogram aliases appearance: never count it twice.
            if similarities:
                sim = sum(similarities)/len(similarities)
                appearance_candidates.append((item.get('player_id'), sim))
                candidates.append(dict(player_id=item.get('player_id'), score=round(sim, 4), basis='appearance_only'))
        if not human and len(groups)==1:
            pid, rows = next(iter(groups.items()))
            similarities=[sim for candidate,sim in appearance_candidates if candidate==pid]
            if similarities:
                # Fixed heuristic, not calibrated probability. Appearance alone cannot identify.
                base=sum(e['weight'] for e in rows)/len(rows)
                score=(.7*base+.3*max(similarities))*min(1,len(rows)/self.min_repeats)
            identity = pid if len(rows)>=self.min_repeats and score>=self.min_confidence and not reasons else 'unknown'
            identity_status='provisional' if identity!='unknown' else 'unknown'
        if human and identity!='unknown':self._reconfirm[key].clear()
        if identity == 'unknown':
            if self._reconfirm[key]:
                identity_status='reconfirm_needed';reasons.extend(sorted(self._reconfirm[key]))
            if not groups:
                if not team:reasons.append('missing_team_evidence')
                if number is None:reasons.append('missing_jersey_evidence')
                if team and number is not None:
                    if tc<self.min_team or jc<self.min_jersey:reasons.append('low_team_or_jersey_score')
                    elif not matches:reasons.append('no_valid_roster_match')
            elif len(groups)==1:
                if len(next(iter(groups.values())))<self.min_repeats:reasons.append('insufficient_independent_observations')
                elif score<self.min_confidence:reasons.append('below_identity_threshold')
            if not reasons:reasons.append('no_usable_identity_evidence')
        result = dict(video_id=obs.get('video_id'),frame=obs.get('frame'),track_id=tid, shot_id=shot, timestamp=ts, identity=identity,
                      identity_status=identity_status,
                      evidence_score=round(score, 4), score_calibrated=False,
                      independent_observations=sum(len(v) for v in groups.values()), evidence=copy.deepcopy(evidence),
                      candidates=copy.deepcopy(sorted(candidates, key=lambda c:c['score'], reverse=True)),
                      review_reasons=list(dict.fromkeys(reasons)))
        self._results[key] = copy.deepcopy(result)
        return result

    def presence(self, timestamp, visible_track_ids, shot_id=0, coverage='partial', substitution_events=None,video_id=None):
        """Explicit visible IDs are required; official/human confirmed events alone
        determine substitution. Full coverage still cannot prove substitution.
        """
        visible, out = set(visible_track_ids or []), []
        for player in self._roster:
            pid = player.get('player_id')
            tracks = [tid for (stored_video,tid, shot), result in self._results.items()
                      if stored_video==video_id and shot == shot_id and result['identity'] == pid and self._result_is_current((stored_video,tid,shot), timestamp)]
            screen = 'unknown'
            if tracks and coverage not in ('unknown', 'cutaway'):
                screen = 'on_screen' if visible.intersection(tracks) else 'off_screen'
            events = [e for e in substitution_events or [] if e.get('player_id') == pid and (e.get('video_id') is None or e.get('video_id')==video_id)
                      and e.get('confirmed') is True and e.get('source')
                      and isinstance(e.get('timestamp'), (int,float)) and 0 <= e['timestamp'] <= timestamp
                      and e.get('status') in ('in','out')]
            event = max(events, key=lambda e:e['timestamp']) if events else None
            court = 'unknown'
            if event:
                court = 'confirmed_substituted_out' if event['status'] == 'out' else 'confirmed_on_court'
            out.append(dict(player_id=pid, screen_state=screen, court_state=court,
                            court_evidence=event, timestamp=timestamp, shot_id=shot_id))
        return out

    def _result_is_current(self,key,timestamp):
        result=self._results.get(key)
        if not result:return False
        if timestamp<result['timestamp']:return False
        if self.max_track_gap is not None and timestamp-self._last_seen[key]>self.max_track_gap:return False
        if result.get('identity_status') in ('human_confirmed','ai_confirmed_spot_checked'):
            evidence_times=[e.get('timestamp') for e in result.get('evidence',[]) if e.get('type')=='human_review' and isinstance(e.get('timestamp'),(int,float))]
            if not evidence_times or (self.max_human_duration is not None and timestamp-max(evidence_times) > self.max_human_duration):return False
            for e in result.get('evidence',[]):
                if e.get('reviewer_kind')=='ai_assisted':
                    scope=(e.get('spot_check') or {}).get('scope') or {}
                    if isinstance(scope.get('end_s'),(int,float)) and timestamp>scope['end_s']:return False
            return True
        return True
