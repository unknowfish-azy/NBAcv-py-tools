"""Single version source used by packaging and runtime outputs."""
__version__ = '0.3.2'
