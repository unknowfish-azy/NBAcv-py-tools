"""Evidence-scored identity resolver; unknown is the safe result."""
from collections import defaultdict
def resolve_identity(track,roster,min_confidence=.8):
    from identity_evidence import IdentityResolver
    obs=dict(track)
    obs.setdefault('timestamp',0.)
    obs.setdefault('shot_id',0)
    if obs.get('track_id') is None:return {'identity':'unknown','confidence':0.,'evidence':[]}
    result=IdentityResolver(min_confidence=min_confidence).update(obs,roster)
    result['confidence']=result['evidence_score']
    result['confidence_kind']='uncalibrated_evidence_score'
    return result

def build_identity_report(rows):
    by=defaultdict(list)
    for raw in rows:
        r=raw.get('resolution',raw) if isinstance(raw,dict) else raw
        by[(r.get("shot_id", 0), r.get("track_id"))].append(r)
    switches=0;unknown=0;resolved=0
    for vals in by.values():
        prev=None
        for r in sorted(vals,key=lambda x:(x.get('frame') if isinstance(x.get('frame'),(int,float)) else x.get('timestamp',0))):
            ident=r.get("identity","unknown")
            if ident=="unknown":unknown+=1
            else:
                resolved+=1
                if prev and ident!=prev:switches+=1
                prev=ident
    return {"tracks":len(by),"id_switches":switches,"unknown_observations":unknown,"resolved_observations":resolved,"identity_unknown_rate":unknown/max(1,unknown+resolved)}
