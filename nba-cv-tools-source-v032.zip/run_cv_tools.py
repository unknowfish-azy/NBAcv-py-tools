"""Portable JSON/JSONL CLI. Exit 2=input/IO error; exit 1=invalid annotation."""
import argparse,json,sys,math,re
from collections import Counter
from nba_cv_version import __version__
from pathlib import Path
from skeleton_labeler import normalize_file,detect_temporal_jumps,frame_number,COCO17,suggest_temporal_speed
from identity_evidence import IdentityResolver
from player_identity_cv import build_identity_report

def read_records(path):
 p=Path(path);text=p.read_text(encoding='utf-8-sig')
 return [json.loads(line) for line in text.splitlines() if line.strip()] if p.suffix.lower()=='.jsonl' else json.loads(text)
def save(out,result):
 out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('x',encoding='utf8') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False)
def queue_path(out):return Path(out).with_suffix('.review_queue.jsonl')
def check_outputs(out):
 for p in (Path(out),queue_path(out)):
  if p.exists():raise ValueError(f'Output exists: {p}; use a new path')
def save_queue(out,rows):
 p=queue_path(out);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf8') as f:
  for row in rows:f.write(json.dumps(dict(schema='nba.review.v1',tool_version=__version__,**row),ensure_ascii=False,allow_nan=False)+'\n')
 return str(p.resolve())
def skeleton_cmd(inp,out,expected=17,input_format='auto',max_displacement=50,normalized_threshold=None,max_speed=None,max_gap=2.0,fps=None,track_map=None,compare_unmarked_points=False,group_id_is_track=False,suggest_speed=False):
 src=Path(inp)
 if not src.exists():raise ValueError('Input does not exist')
 check_outputs(out)
 files=[src] if src.is_file() else sorted(p for p in src.glob('*.json') if p.resolve()!=Path(out).resolve() and (not track_map or p.resolve()!=Path(track_map).resolve()))
 if not files:raise ValueError('No input JSON files')
 if fps is not None and (not math.isfinite(fps) or fps<=0):raise ValueError('fps must be finite and positive')
 if expected!=17 or input_format not in ('auto','labelme','pose17','tracks'):raise ValueError('Invalid format or expected point count')
 detect_temporal_jumps([],max_displacement,normalized_threshold,max_speed,max_gap)
 mapping=json.loads(Path(track_map).read_text(encoding='utf-8-sig')) if track_map else {}
 if not isinstance(mapping,dict):raise ValueError('track-map must be an object')
 if any(isinstance(v,dict) for v in mapping.values()):
  if set(mapping)-{'label','group_id'}:raise ValueError('Use only label and group_id namespaces')
  label_map=mapping.get('label',{});group_map=mapping.get('group_id',{})
 else:label_map=mapping;group_map={}
 for values in (label_map,group_map):
  if not isinstance(values,dict) or any(not isinstance(v,(str,int)) or isinstance(v,bool) or v=='' for v in values.values()):raise ValueError('Mapping values must be nonempty string/integer track IDs')
 results=[];all_rows=[]
 for p in files:
  try:
   r=normalize_file(p,expected,input_format);r['source_file']=str(p)
   rows=r.get('rows')
   if rows is None:
    frame_num=r.get('frame')
    if frame_num is None and re.search(r'\d+',p.stem):frame_num=frame_number(p.stem)
    rows=[]
    for index,x in enumerate(r.get('people',[])):
     explicit=x.get('explicit_track_id')
     fallback=x.get('track_id') if group_id_is_track else None
     raw_group=x.get('track_id')
     label_id=label_map.get(x.get('label'));group_id=group_map.get(str(raw_group))
     if label_id is not None and group_id is not None and label_id!=group_id:raise ValueError('Conflicting label and group_id mappings')
     track_id=label_id if label_id is not None else group_id if group_id is not None else explicit if explicit is not None else fallback
     timestamp=r.get('timestamp_s')
     if timestamp is None and fps is not None and frame_num is not None:timestamp=frame_num/fps
     row=dict(x,frame=frame_num,timestamp_s=timestamp,track_id=track_id,
              shot_id=r.get('shot_id',0),video_id=r.get('video_id',str(src.resolve())),image_height=r.get('image_height'),
              visibility_source='annotation_v',compare_unmarked_points=compare_unmarked_points)
     if frame_num is None and timestamp is None:row['track_id']=None;row['review_reasons']=['missing_frame_or_timestamp']
     rows.append(row)
   for row in rows:all_rows.append(dict(row,_file_index=len(results)))
   r['temporal']=[]
   results.append(r)
  except (ValueError,TypeError) as e:results.append({'source_file':str(p),'status':'invalid','error':str(e)})
 for row in detect_temporal_jumps(all_rows,max_displacement,normalized_threshold,max_speed,max_gap):
  file_index=row.pop('_file_index');results[file_index]['temporal'].append(row)
 result={'schema':'nba.pose17.v2','tool_version':__version__,'files':results}
 if suggest_speed:result['speed_advisory']=suggest_temporal_speed(all_rows,max_gap=max_gap)
 queue=[]
 for f in results:
  if f.get('status')=='invalid':queue.append(dict(kind='skeleton',source_file=f['source_file'],frame=None,track_id=None,timestamp_s=None,status='invalid',priority='high',reasons=['invalid_annotation']))
  for row in f.get('temporal',[]):
   if row.get('temporal_status')=='REVIEW' or row.get('review_reasons'):
    queue.append(dict(kind='skeleton',source_file=f.get('source_file'),frame=row.get('frame'),track_id=row.get('track_id'),shot_id=row.get('shot_id',0),timestamp_s=row.get('timestamp_s',row.get('timestamp')),status=row.get('temporal_status'),priority='high' if row.get('temporal_status')=='REVIEW' else 'normal',reasons=row.get('review_reasons',[])))
 result['review_queue']=save_queue(out,queue)
 result['review_items']=len(queue)
 save(out,result)
 return {'files':len(results),'invalid':sum(x['status']=='invalid' for x in results)}
def identity_cmd(tracks,roster,out,min_confidence=.8,gallery=None,max_human_duration=300.0):
 check_outputs(out)
 data=read_records(tracks);players=read_records(roster)
 rows=data if isinstance(data,list) else data.get('tracks',data.get('rows'))
 players=players if isinstance(players,list) else players.get('players')
 if not isinstance(rows,list) or not isinstance(players,list) or any(not isinstance(x,dict) for x in rows+players):raise ValueError('tracks and players must be arrays of objects')
 resolver=IdentityResolver(min_confidence=min_confidence,gallery=read_records(gallery) if gallery else None,max_human_duration=max_human_duration);resolved=[]
 for r in sorted(rows,key=lambda r:r.get('timestamp',r.get('timestamp_s',-1))):
  r=dict(r);r.setdefault('timestamp',r.get('timestamp_s'))
  candidate=resolver.update(r,players)
  resolved.append(dict(candidate,input=r,resolution=candidate))
 flat=[x['resolution'] for x in resolved]
 result={'schema':'nba.identity.v2','tool_version':__version__,'rows':resolved,'report':build_identity_report(flat),'unknown_queue':[r for r in resolved if r['resolution']['identity']=='unknown']}
 queue=[dict(kind='identity',source_file=str(tracks),frame=r.get('frame'),track_id=r.get('track_id'),video_id=r.get('video_id'),shot_id=r.get('shot_id'),timestamp_s=r.get('timestamp'),status=r['identity_status'],priority='high' if r['identity_status']=='reconfirm_needed' else 'normal',reasons=r['review_reasons']) for r in flat if r['identity']=='unknown' or r['review_reasons']]
 result['review_queue']=save_queue(out,queue)
 result['report']['reason_counts']=dict(Counter(reason for r in queue for reason in r['reasons']))
 result['report']['review_items']=len(queue)
 save(out,result);return result['report']
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--version',action='version',version=__version__);sub=ap.add_subparsers(dest='cmd',required=True)
 s=sub.add_parser('skeleton');s.add_argument('input');s.add_argument('output');s.add_argument('--expected-points',type=int,default=17);s.add_argument('--format',choices=['auto','labelme','pose17','tracks'],default='auto');s.add_argument('--max-displacement',type=float,default=50);s.add_argument('--normalized-threshold',type=float)
 s.add_argument('--max-speed',type=float,help='Pixels/second; requires timestamps');s.add_argument('--max-gap',type=float,default=2.0);s.add_argument('--fps',type=float);s.add_argument('--track-map');s.add_argument('--compare-unmarked-points',action='store_true');s.add_argument('--group-id-is-track',action='store_true')
 s.add_argument('--suggest-speed',action='store_true',help='Report P99 x 1.2 speed suggestion without changing threshold')
 i=sub.add_parser('identity');i.add_argument('tracks');i.add_argument('roster');i.add_argument('output');i.add_argument('--min-confidence',type=float,default=.8);i.add_argument('--gallery');i.add_argument('--max-human-duration',type=float,default=300.0);a=ap.parse_args()
 try:
  result=skeleton_cmd(a.input,a.output,a.expected_points,a.format,a.max_displacement,a.normalized_threshold,a.max_speed,a.max_gap,a.fps,a.track_map,a.compare_unmarked_points,a.group_id_is_track,a.suggest_speed) if a.cmd=='skeleton' else identity_cmd(a.tracks,a.roster,a.output,a.min_confidence,a.gallery,a.max_human_duration)
  print(json.dumps(result,ensure_ascii=False));return 1 if result.get('invalid',0) else 0
 except (ValueError,TypeError,OSError,KeyError) as e:
  print(json.dumps({'status':'ERROR','error':str(e)},ensure_ascii=False),file=sys.stderr);return 2
if __name__=='__main__':sys.exit(main())
