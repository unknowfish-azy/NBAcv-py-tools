"""COCO17 normalization with per-joint validation and explicit temporal gates."""
import json, math, re
from collections import Counter
from pathlib import Path
COCO17=['nose','left_eye','right_eye','left_ear','right_ear','left_shoulder','right_shoulder','left_elbow','right_elbow','left_wrist','right_wrist','left_hip','right_hip','left_knee','right_knee','left_ankle','right_ankle']
def canonical_joint_names(names):
 if not isinstance(names,list):return names
 aliases={name.replace('left_','l_').replace('right_','r_'):name for name in COCO17}
 result=[]
 for name in names:
  if not isinstance(name,str):return names
  normalized=re.sub(r'([a-z])([A-Z])',r'\1_\2',name).strip().lower().replace('-','_').replace(' ','_')
  result.append(aliases.get(normalized,normalized))
 return result
def frame_number(value):
 if isinstance(value,(int,float)):return float(value)
 parts=re.findall(r'\d+',str(value));return int(parts[-1]) if parts else 0

def suggest_temporal_speed(rows, percentile=99, multiplier=1.2, min_samples=3, max_gap=2.0):
 if not math.isfinite(percentile) or not 0<percentile<=100 or not math.isfinite(multiplier) or multiplier<=0 or min_samples<1:raise ValueError('Invalid speed suggestion parameters')
 valid=[]
 for row in rows:
  kp=row.get('keypoints',[])
  if len(kp)!=17 or canonical_joint_names(row.get('joint_names',COCO17))!=COCO17 or validate_pose(kp)['invalid']:continue
  valid.append(row)
 checked=detect_temporal_jumps(valid,max_speed=1e300,max_gap=max_gap)
 samples=[max(r['joint_speeds_px_s'].values()) for r in checked if r.get('joint_speeds_px_s') and r.get('temporal_status')=='PASS']
 base={'samples':len(samples),'percentile':percentile,'multiplier':multiplier,'sample_unit':'max_joint_speed_per_track_interval','max_gap_s':max_gap,'applied':False}
 if len(samples)<min_samples:return dict(base,suggested_max_speed=None,status='INSUFFICIENT_DATA')
 samples.sort()
 index=min(len(samples)-1,max(0,math.ceil(len(samples)*percentile/100)-1))
 value=samples[index]
 return dict(base,observed_percentile_px_s=value,suggested_max_speed=round(value*multiplier,3) if value>0 else None,status='ADVISORY_UNCALIBRATED' if value>0 else 'INSUFFICIENT_MOTION')

def validate_pose(keypoints,width=None,height=None):
 out=[];issues=[]
 if not isinstance(keypoints,list):return {'invalid':1,'keypoints':[],'issues':['points_not_array']}
 for i,p in enumerate(keypoints):
  bad=not isinstance(p,(list,tuple)) or len(p) not in (2,3)
  if not bad:
   x,y=p[:2];v=p[2] if len(p)==3 else 0
   bad=not all(isinstance(n,(int,float)) and not isinstance(n,bool) and math.isfinite(n) for n in (x,y)) or v not in (0,1,2)
   if not bad:bad=x<0 or y<0 or (width is not None and x>width) or (height is not None and y>height)
  if bad:out.append([None,None,0]);issues.append({'joint_index':i,'reason':'invalid_coordinate_or_visibility'})
  else:out.append([float(x),float(y),int(v)])
 return {'invalid':len(issues),'keypoints':out,'issues':issues}

def parse_labelme(data,expected_points=17):
 if expected_points!=17:raise ValueError('Only COCO17 human pose supported; court keypoints need separate schema')
 if not isinstance(data,dict) or not isinstance(data.get('shapes'),list):raise ValueError('Expected LabelMe shapes array')
 people=[];ignored=0
 for s in data['shapes']:
  if not isinstance(s,dict) or s.get('shape_type')!='points':ignored+=1;continue
  q=validate_pose(s.get('points'),data.get('imageWidth'),data.get('imageHeight'))
  flags=s.get('flags') or {};review=flags.get('human_verified') is True and isinstance(flags.get('reviewer'),str) and bool(flags['reviewer'].strip())
  status='invalid' if q['invalid'] or len(q['keypoints'])!=17 else 'human_verified' if review else 'human_pending'
  people.append({'label':s.get('label'),'track_id':s.get('group_id'),'explicit_track_id':s.get('track_id'),'joint_names':COCO17,'keypoints':q['keypoints'],'status':status,'issues':q['issues'],'review_source':flags if review else None})
 return {'schema':'nba.pose17.v2','status':'invalid' if any(p['status']=='invalid' for p in people) else 'human_pending','people':people,'ignored_shapes':ignored,'image_width':data.get('imageWidth'),'image_height':data.get('imageHeight'),'frame':data.get('frame'),'timestamp_s':data.get('timestamp_s',data.get('timestamp')),'shot_id':data.get('shot_id',0),'video_id':data.get('video_id')}

def detect_temporal_jumps(rows,max_displacement=50,normalized_threshold=None,max_speed=None,max_gap=2.0):
 if max_displacement<=0 or (normalized_threshold is not None and normalized_threshold<=0):raise ValueError('Threshold must be positive')
 if any(v is not None and (not isinstance(v,(int,float)) or not math.isfinite(v) or v<=0) for v in (max_displacement,normalized_threshold,max_speed,max_gap)):raise ValueError('Thresholds must be finite and positive')
 prior={};out=[]
 def row_key(row):return (row.get('video_id'),row.get('shot_id',0),row.get('track_id'))
 def frame_key(row):return row_key(row)+(row.get('timestamp_s',row.get('timestamp')) if row.get('timestamp_s',row.get('timestamp')) is not None else row.get('frame'),)
 counts=Counter(frame_key(row) for row in rows if row.get('track_id') is not None)
 for row in sorted(rows,key=lambda r:(r.get('timestamp_s') if isinstance(r.get('timestamp_s'),(int,float)) else frame_number(r.get('frame',r.get('timestamp',0))))):
  item=dict(row);reasons=list(row.get('review_reasons',[]));kp=row.get('keypoints',[]);names=canonical_joint_names(row.get('joint_names',COCO17))
  duplicate=row.get('track_id') is not None and counts[frame_key(row)]>1
  if duplicate:reasons.append('duplicate_track_in_frame')
  if len(kp)!=17 or names!=COCO17:reasons.append('missing_or_incompatible_joint_layout')
  tid=row.get('track_id');key=(row.get('video_id'),row.get('shot_id',0),tid)
  valid=validate_pose(kp);cur={COCO17[i]:p for i,p in enumerate(valid['keypoints'][:17]) if p[0] is not None and p[2]>0}
  if row.get('compare_unmarked_points'):
   cur={COCO17[i]:p for i,p in enumerate(valid['keypoints'][:17]) if p[0] is not None}
   item['comparison_assumption']='all_valid_coordinates_including_unmarked'
  confidence=row.get('keypoint_confidence',[])
  if row.get('visibility_source')=='model_confidence_separate':
   cur={COCO17[i]:p for i,p in enumerate(valid['keypoints'][:17]) if p[0] is not None and i<len(confidence) and isinstance(confidence[i],(int,float)) and confidence[i]>=.5}
  if not cur and not valid['invalid']:
   reasons.append('low_model_keypoint_confidence' if row.get('visibility_source')=='model_confidence_separate' else 'missing_visibility')
  if valid['invalid']:reasons.append('invalid_points')
  old=prior.get(key) if tid is not None else None;threshold=max_displacement
  if normalized_threshold is not None:
   box=row.get('bbox');scale=(box[3]-box[1]) if isinstance(box,list) and len(box)==4 else row.get('image_height')
   if not isinstance(scale,(int,float)) or scale<=0:reasons.append('missing_normalization_scale');old=None
   else:threshold=normalized_threshold*scale
  dt=None
  if old is not None:
   prev_ts=old.get('__timestamp_s'); cur_ts=row.get('timestamp_s', row.get('timestamp'))
   if isinstance(prev_ts,(int,float)) and isinstance(cur_ts,(int,float)) and not isinstance(prev_ts,bool) and not isinstance(cur_ts,bool) and math.isfinite(prev_ts) and math.isfinite(cur_ts):
    dt=cur_ts-prev_ts
    if dt<=0: reasons.append('nonpositive_timestamp_interval');old=None
    elif max_gap is not None and dt>max_gap: reasons.append('track_gap'); old=None
   elif max_speed is not None: reasons.append('missing_timestamp_for_speed'); old=None
  if old is not None:
   if not old.keys() & cur.keys():
    item['comparison_note']='no_comparable_visible_joints'
   for name in old.keys() & cur.keys():
    distance=math.dist(old[name][:2],cur[name][:2])
    if dt and dt>0:item.setdefault('joint_speeds_px_s',{})[name]=distance/dt
    limit=threshold if max_speed is None or not dt or dt<=0 else max_speed*dt
    if distance>limit:reasons.append({'joint':name,'displacement_px':distance,'threshold_px':limit,'speed_px_s':distance/dt if dt else None})
  item['temporal_status']='NOT_RUN' if tid is None or old is None else 'REVIEW' if reasons else 'PASS'
  if item.get('comparison_note'):item['temporal_status']='NOT_RUN'
  item['review_reasons']=reasons+(['missing_track_id'] if tid is None else [])
  item['status']='review' if any(r not in ('missing_visibility','low_model_keypoint_confidence') for r in reasons) else row.get('status','human_pending')
  if not cur:item['temporal_status']='NOT_RUN'
  out.append(item)
  if duplicate:item['temporal_status']='REVIEW'
  if tid is not None and not duplicate:
   cur['__timestamp_s']=row.get('timestamp_s',row.get('timestamp'))
   prior[key]=cur
 return out

def normalize_file(path,expected_points=17,input_format='auto'):
 if expected_points!=17:raise ValueError('Expected human COCO17, not court layout')
 data=json.loads(Path(path).read_text(encoding='utf-8-sig'))
 if input_format=='labelme' or (input_format=='auto' and isinstance(data,dict) and 'shapes' in data):return parse_labelme(data)
 if input_format not in ('auto','pose17','tracks'):raise ValueError('Unsupported format')
 if isinstance(data,list):rows=data
 elif isinstance(data,dict) and isinstance(data.get('rows'),list):rows=data['rows']
 elif isinstance(data,dict) and data and all(isinstance(v,list) for v in data.values()):
  rows=[dict(p,frame=frame) for frame,persons in data.items() for p in persons if isinstance(p,dict)]
 else:raise ValueError('Unsupported pose structure; specify labelme, pose17 or tracks')
 normalized=[]
 for row in rows:
  if not isinstance(row,dict):normalized.append({'frame':0,'keypoints':[],'status':'invalid'});continue
  raw=row.get('keypoints',row.get('kpts',[]));raw=raw if isinstance(raw,list) else []
  incompatible_names='joint_names' in row and canonical_joint_names(row.get('joint_names')) != COCO17
  if len(raw)==51 and all(isinstance(x,(int,float)) for x in raw):raw=[raw[i:i+3] for i in range(0,51,3)]
  confidence=None
  if ('kpts' in row and 'keypoints' not in row) or row.get('keypoint_format')=='xy_confidence' or 'keypoint_confidence' in row:
   scores=row.get('scores',[])
   existing=row.get('keypoint_confidence',[])
   confidence=[existing[i] if i<len(existing) else p[2] if isinstance(p,(list,tuple)) and len(p)==3 else scores[i] if i<len(scores) else None for i,p in enumerate(raw)]
   raw=[list(p[:2])+[0] if isinstance(p,(list,tuple)) and len(p)==3 else p for p in raw]
  q=validate_pose(raw,row.get('image_width'),row.get('image_height'));n=dict(row,keypoints=q['keypoints'],joint_names=COCO17,status='invalid' if q['invalid'] or len(raw)!=17 or incompatible_names else 'human_pending',issues=q['issues']+(['incompatible_joint_layout'] if incompatible_names else []))
  if confidence is not None:
   n['keypoint_confidence']=confidence
   for i,c in enumerate(confidence):
    if isinstance(c,bool) or not isinstance(c,(int,float)) or not math.isfinite(c) or not 0<=c<=1:
     n['status']='invalid';n['issues'].append({'joint_index':i,'reason':'invalid_model_confidence'});q['invalid']+=1
  if n['status'] != 'invalid' and (not row.get('image_width') or not row.get('image_height')):
   n['bounds_check']='NOT_RUN'; n['status']='NOT_RUN' if not q['invalid'] and len(raw)==17 else 'invalid'
  n['visibility_source']='model_confidence_separate' if confidence is not None else row.get('visibility_source','annotation_v')
  n['bounds_check']='CHECKED' if row.get('image_width') and row.get('image_height') else 'NOT_RUN'
  normalized.append(n)
 return {'schema':'nba.pose17.v2','status':'invalid' if any(r['status']=='invalid' for r in normalized) else 'human_pending','rows':sorted(normalized,key=lambda r:(r.get('timestamp_s') if isinstance(r.get('timestamp_s'),(int,float)) else frame_number(r.get('frame',0))))}
