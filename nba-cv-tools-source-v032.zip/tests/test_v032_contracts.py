import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from identity_evidence import IdentityResolver
from skeleton_labeler import suggest_temporal_speed
from run_cv_tools import skeleton_cmd, identity_cmd

ROSTER=[{'player_id':'p','team':'HOU','jersey_number':1}]
def assisted():
    return {'type':'human_review','reviewer_kind':'ai_assisted','reviewer':'vision_model','human_reviewer':'person',
            'player_id':'p','timestamp':0,'confirmed':True,'evidence_id':'check1',
            'spot_check':{'approved':True,'passed':3,'sampled':3,'required':3,'population':30,
                          'source':'audit.json','sampling_method':'random',
                          'scope':{'video_id':'v','shot_id':0,'track_id':1,'start_s':0,'end_s':10}}}
def obs(t,**kw):
    return dict(timestamp=t,video_id='v',shot_id=0,track_id=1,**kw)

class V032Contracts(unittest.TestCase):
    def test_assisted_approval_does_not_cross_scope(self):
        for field,value in [('shot_id',1),('track_id',2),('video_id','other')]:
            e=assisted();e['spot_check']['scope'][field]=value
            r=IdentityResolver().update(obs(0,identity_evidence=[e]),ROSTER)
            self.assertEqual(r['identity'],'unknown')

    def test_assisted_scope_expiry_and_revoke(self):
        r=IdentityResolver(max_track_gap=20)
        r.update(obs(0,identity_evidence=[assisted()]),ROSTER)
        result=r.update(obs(11),ROSTER)
        self.assertEqual(result['identity_status'],'reconfirm_needed')
        r=IdentityResolver();r.update(obs(0,identity_evidence=[assisted()]),ROSTER)
        revoke={'type':'human_review_revoke','evidence_id':'check1','reviewer':'person','timestamp':1}
        result=r.update(obs(1,identity_evidence=[revoke,assisted()]),ROSTER)
        self.assertEqual(result['identity'],'unknown')

    def test_direct_human_explicit_scope_is_enforced(self):
        e={'type':'human_review','reviewer':'person','player_id':'p','timestamp':0,'confirmed':True,'video_id':'other','track_id':99}
        result=IdentityResolver().update(obs(0,identity_evidence=[e]),ROSTER)
        self.assertEqual(result['identity'],'unknown')

    def test_returned_evidence_is_deep_copy_and_presence_expires(self):
        r=IdentityResolver(max_human_duration=300,max_track_gap=10)
        e=assisted();e['spot_check']['scope']['end_s']=1
        result=r.update(obs(0,identity_evidence=[e]),ROSTER)
        result['evidence'][0]['spot_check']['scope']['end_s']=100
        self.assertEqual(r.update(obs(2),ROSTER)['identity'],'unknown')
        r=IdentityResolver(max_human_duration=1);r.update(obs(0,identity_evidence=[{'type':'human_review','reviewer':'person','player_id':'p','timestamp':0,'confirmed':True}]),ROSTER)
        self.assertEqual(r.presence(100,[1],video_id='v')[0]['screen_state'],'unknown')

    def test_presence_uses_evidence_time_and_ai_scope_not_last_update(self):
        r=IdentityResolver(max_human_duration=2,max_track_gap=10)
        r.update(obs(0,identity_evidence=[{'type':'human_review','reviewer':'person','player_id':'p','timestamp':0,'confirmed':True}]),ROSTER)
        r.update(obs(1),ROSTER)
        self.assertEqual(r.presence(2.5,[1],video_id='v')[0]['screen_state'],'unknown')
        r=IdentityResolver(max_track_gap=100)
        r.update(obs(0,identity_evidence=[assisted()]),ROSTER)
        self.assertEqual(r.presence(11,[1],video_id='v')[0]['screen_state'],'unknown')

    def test_cli_ai_assisted_roundtrip_and_high_priority_reconfirmation(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);inp=p/'i.json';out=p/'o.json';roster=p/'r.json'
            inp.write_text(json.dumps([obs(0,identity_evidence=[assisted()]),obs(1),obs(2)]));roster.write_text(json.dumps(ROSTER))
            cli=Path(__file__).resolve().parents[1]/'run_cv_tools.py'
            r=subprocess.run([sys.executable,str(cli),'identity',str(inp),str(roster),str(out),'--max-human-duration','1'],capture_output=True,text=True)
            self.assertEqual(r.returncode,0,r.stderr)
            data=json.loads(out.read_text());self.assertEqual(data['rows'][0]['identity_status'],'ai_confirmed_spot_checked')
            queue=[json.loads(x) for x in Path(data['review_queue']).read_text().splitlines()]
            self.assertEqual(queue[-1]['priority'],'high');self.assertIn('human_review_expired',queue[-1]['reasons'])

    def test_substitution_event_does_not_cross_video(self):
        r=IdentityResolver();r.update(obs(0),ROSTER)
        event={'video_id':'other','player_id':'p','status':'out','confirmed':True,'source':'official','timestamp':1}
        self.assertEqual(r.presence(2,[],video_id='v',substitution_events=[event])[0]['court_state'],'unknown')

    def test_invalid_spot_counts_never_confirm(self):
        for changes in [{'passed':True},{'sampled':-1},{'passed':4},{'sampled':4},{'population':2},{'approved':False}]:
            e=assisted();e['spot_check'].update(changes)
            self.assertEqual(IdentityResolver().update(obs(0,identity_evidence=[e]),ROSTER)['identity'],'unknown')

    def test_speed_advisory_excludes_gaps_shots_hidden_and_bad_layouts(self):
        def row(t,x,**kwargs):return dict(timestamp_s=t,track_id=1,keypoints=[[x,0,2]]*17,**kwargs)
        rows=[row(0,0),row(.4,20),row(10,10000),row(10.4,0,shot_id=1)]
        result=suggest_temporal_speed(rows,max_gap=2,min_samples=1)
        self.assertEqual(result['samples'],1)
        self.assertAlmostEqual(result['suggested_max_speed'],60)
        rows[1]['keypoints'][-1]=[10000,0,0]
        self.assertAlmostEqual(suggest_temporal_speed(rows,max_gap=2,min_samples=1)['suggested_max_speed'],60)
        rows[1]['keypoints'].pop()
        self.assertEqual(suggest_temporal_speed(rows,max_gap=2,min_samples=1)['samples'],0)

    def test_identity_queue_preserves_existing_output(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);inp=p/'in.json';roster=p/'r.json';out=p/'out.json'
            inp.write_text(json.dumps([obs(0)]));roster.write_text(json.dumps(ROSTER))
            identity_cmd(inp,roster,out)
            data=json.loads(out.read_text())
            queue=Path(data['review_queue']);rows=[json.loads(x) for x in queue.read_text().splitlines()]
            self.assertEqual(rows[0]['kind'],'identity')
            self.assertIn('missing_team_evidence',rows[0]['reasons'])
            out.unlink()
            with self.assertRaises(ValueError):identity_cmd(inp,roster,out)
            self.assertEqual(len(queue.read_text().splitlines()),1)

    def test_group_mapping_explicit_and_missing_visibility_warning(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);inp=p/'1.json';out=p/'out.json';mapping=p/'map.txt'
            inp.write_text(json.dumps({'shapes':[{'shape_type':'points','label':'other','group_id':9,'points':[[1,2]]*17}]}))
            mapping.write_text(json.dumps({'group_id':{'9':'p'}}))
            skeleton_cmd(inp,out,track_map=mapping,fps=2.5)
            data=json.loads(out.read_text());row=data['files'][0]['temporal'][0]
            self.assertEqual(row['track_id'],'p')
            self.assertIn('missing_visibility',row['review_reasons'])
            self.assertEqual(row['temporal_status'],'NOT_RUN')
            q=[json.loads(x) for x in Path(data['review_queue']).read_text().splitlines()]
            self.assertEqual(q[0]['kind'],'skeleton')

    def test_cli_version_matches_output(self):
        cli=Path(__file__).resolve().parents[1]/'run_cv_tools.py'
        r=subprocess.run([sys.executable,str(cli),'--version'],capture_output=True,text=True)
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertIn('0.3.2',r.stdout)
