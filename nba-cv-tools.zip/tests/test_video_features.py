import unittest,sys,numpy as np
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from video_identity_pipeline import visual_features
class Features(unittest.TestCase):
 def test_red(self):
  a=np.zeros((100,40,3),np.uint8);a[:,:,2]=255
  self.assertEqual(visual_features(a)['jersey_color'],'red')
 def test_small(self):
  self.assertEqual(visual_features(np.zeros((3,3,3),np.uint8))['status'],'insufficient_pixels')
